-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_gcfkdbpgisfzrxxfmyiqdzayhjnqdatbmepl` (`primaryOwnerId`),
  CONSTRAINT `fk_gcfkdbpgisfzrxxfmyiqdzayhjnqdatbmepl` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sqzdvagayvhxnroplzvgcyscppadnfurpssi` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_blakyhbfevytepogojyheucjnbpkzmtikmpy` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_tiefnwoypqhwvxeghqeacakmwqborxocijbk` (`dateRead`),
  KEY `fk_lccuksodsnnkcnclqltrwqgxesixdzedugxa` (`pluginId`),
  CONSTRAINT `fk_lccuksodsnnkcnclqltrwqgxesixdzedugxa` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tzgxihbyysquswwcbjgozfpldugwyhwxtnvy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kocrnztfspmtwlsdkwznhgoqgcmkiowtpjnk` (`sessionId`,`volumeId`),
  KEY `idx_txawjvrnxtrejvxqqnzqrziwisreswnuqfxr` (`volumeId`),
  CONSTRAINT `fk_gemphhmttzcrechwtrpokmievhfozhsyjwdn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ujgxvpwumzdishuvxsaaribxjmkefdtsaaoi` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mtdaaftbaowpeppopcpsjmienhpfnedrqxkr` (`filename`,`folderId`),
  KEY `idx_wjrmjaneyjdbwgsygerzxylddncsupoyftrv` (`folderId`),
  KEY `idx_vmqhrbxvadfwuboqwzsikkrtngkljnestivx` (`volumeId`),
  KEY `fk_xfrkshflpusucxifrwpzhpcgsqdwjqdtkyjs` (`uploaderId`),
  CONSTRAINT `fk_hnwtdwszekuldeznnntoaukxolkybawyykfi` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pgpcwciwtxzrkxykimrfgeuqagkpyfhrrsgc` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_weltvpebfrkqsjvwafkfmgmlvlknhmacabao` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xfrkshflpusucxifrwpzhpcgsqdwjqdtkyjs` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_ycndqgkzbjkzggfmyywrxatcvgtiuhbmsbwn` (`siteId`),
  CONSTRAINT `fk_edlmhlxsathorptisigsteentdnptaywrrhn` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ycndqgkzbjkzggfmyywrxatcvgtiuhbmsbwn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_eypzyjlhghpzorbmevaiyqwqrspmapwwfqip` (`userId`),
  CONSTRAINT `fk_eypzyjlhghpzorbmevaiyqwqrspmapwwfqip` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kyodlucuzrumsmcazyfagqoydsfwtutyrngt` (`groupId`),
  KEY `fk_qvhxvuidfmswesnzykkxyvshcgmnznecpizp` (`parentId`),
  CONSTRAINT `fk_jhtxnyuzluvcipnozmbljwllobrluyictjev` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qvhxvuidfmswesnzykkxyvshcgmnznecpizp` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tgmdadhoakxkjqeyfftkgpwzwclmoexjsngl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sxtpwnsiudbvzlcuowqpsefazogqipesqhcg` (`name`),
  KEY `idx_qycygawiuxlwwpvdyqivxfpnrkdnexwqpjdo` (`handle`),
  KEY `idx_ldpqvjzkrunpebfhhbdwrhhgdwikjwzjuera` (`structureId`),
  KEY `idx_zkegjvxaxgqsijmysahvqmipdoxyasonlixw` (`fieldLayoutId`),
  KEY `idx_ggyriiiylkkxqvtlukrnjddwtzxpparsdfhs` (`dateDeleted`),
  CONSTRAINT `fk_ojuysxsnvhwbtobhwfyhlpqalqsnvauabipf` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ozkqyxhzzzrbyuphpsygqxycysbguphbpwtm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mnhtmtjwsizyeysnwkisfepjubrvtrqaodzf` (`groupId`,`siteId`),
  KEY `idx_tejtjhgboemnutiuysrtrqwkioeknbqiajgm` (`siteId`),
  CONSTRAINT `fk_ltlrekykkcmalbptkpacysnbbvyffskjaopc` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ovdfbzyqyrokdlqyuzlpjoarvysigdukolnb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_klveajhxotzfvxtszkimwbxldvinknjumyzv` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_tnmuezrkzjpmqztkgyvancsnxprcyoyxgqnh` (`siteId`),
  KEY `fk_szsmznuqyyzjxxdgzonjnecrdrzsousybtwj` (`userId`),
  CONSTRAINT `fk_nlerlfhpwvymwjuzbrhfybbdxfiqaetwwsji` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_szsmznuqyyzjxxdgzonjnecrdrzsousybtwj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tnmuezrkzjpmqztkgyvancsnxprcyoyxgqnh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_qkaaabazrljsfjrcltihckwycrpjtetjpgwm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_aglmksqcbrublbjqnptxcisjaiyywfozusyo` (`siteId`),
  KEY `fk_kmtofrotgufargzxwcguqfkwdsxkfnnbbiow` (`fieldId`),
  KEY `fk_zcbqfotalvjkokgiqecsqwamrjrouznmpips` (`userId`),
  CONSTRAINT `fk_aglmksqcbrublbjqnptxcisjaiyywfozusyo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kmtofrotgufargzxwcguqfkwdsxkfnnbbiow` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tiqdurewftehkhvphecfmbjegmtowyqqxxsq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zcbqfotalvjkokgiqecsqwamrjrouznmpips` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_agijwnidbxevghnjikitapgwdrrpdcszrgun` (`userId`),
  CONSTRAINT `fk_agijwnidbxevghnjikitapgwdrrpdcszrgun` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kxptwvfpozjjdsevtvpxorkbnvpzltfloinp` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_yfuvvcvvvvuibsadprhmevxhlhwjzwrzafla` (`creatorId`,`provisional`),
  KEY `idx_duuuwroorzkfdnbpujxxptkhgnmowsdtmkkr` (`saved`),
  KEY `fk_oyammqhvfjecxdenewltsdjatbyrqngiesbc` (`canonicalId`),
  CONSTRAINT `fk_oyammqhvfjecxdenewltsdjatbyrqngiesbc` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shkdwpmrciughdltwdboujibjrdvavagaqed` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_gslmcdikqxoshqzsxepkkosoqczmsamfbfkx` (`elementId`,`timestamp`,`userId`),
  KEY `fk_uczymbcbbrhrohvcoiwjwgauxicahiiztvuf` (`userId`),
  KEY `fk_pmdpuifgmpvpaszpstwsjcxtgcrewoivnncz` (`siteId`),
  KEY `fk_pgsegmeoxobunklbrsyacrtzonxekqbqcocl` (`draftId`),
  CONSTRAINT `fk_pgsegmeoxobunklbrsyacrtzonxekqbqcocl` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pmdpuifgmpvpaszpstwsjcxtgcrewoivnncz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uczymbcbbrhrohvcoiwjwgauxicahiiztvuf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ujydemoezdzheuukqxqouwmoztoxfegquqhb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bemyrbyjhjoewyljfgqqhmoirtqvdcsuuiuu` (`dateDeleted`),
  KEY `idx_nvshmcrqmwhlyyksoynfidqqivymijtwwyvj` (`fieldLayoutId`),
  KEY `idx_ahogjrqmpmjydmfggznowyfauhlsvkuixlsz` (`type`),
  KEY `idx_kdrrymoojhqlwbtcwqtdjcwjcjsmwkktsfpa` (`enabled`),
  KEY `idx_saatugrzxwinylbjssmsubglmtylbngzkpyy` (`canonicalId`),
  KEY `idx_tnrgdnqvsdyekrzlpgvwboagyutwfhdxagvv` (`archived`,`dateCreated`),
  KEY `idx_flsyikcywgpghebusucyxvhgxsmnjarellci` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_adqppwlrqrrxefsqbigfyznupszbrsjchaxe` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_zyqkmdopgnqkctgcjtcodayftvkclnxlemxl` (`draftId`),
  KEY `fk_iniofvpsuipzbgqfpobbfjcpjioaxhngiipi` (`revisionId`),
  CONSTRAINT `fk_iniofvpsuipzbgqfpobbfjcpjioaxhngiipi` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pgrlwlewcupylgxqsgutxdymispjmnnfiwof` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rqgzufuzdupjfejvkvhukkkvdxrmqmpjctgz` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zyqkmdopgnqkctgcjtcodayftvkclnxlemxl` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_uzyiintcstxjswjbdirsjhjohurcatgzctcf` (`timestamp`),
  CONSTRAINT `fk_aohhrndelqaslhbzebuttadbwznqsqcuzgwr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_zlzksukwblybmvrlabutxrggpkeguqwedmkl` (`ownerId`),
  CONSTRAINT `fk_vtijapcyzujupzfdfjagtmkxopoialsdjsrx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zlzksukwblybmvrlabutxrggpkeguqwedmkl` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yvrejggqrrylkezzeiwddrkxfooqnfqoavse` (`elementId`,`siteId`),
  KEY `idx_metnzxwlegpnctvpzkjjzrdhlknxkymbapzx` (`siteId`),
  KEY `idx_bhmekicdyanmvsrdryhnjvkwbdsjyherpbvi` (`title`,`siteId`),
  KEY `idx_sdcrmbvmarqkeoukxwjnlfncqpvhauyutsyl` (`slug`,`siteId`),
  KEY `idx_pgmcbgguccrfbkhodkbjpehstcototbyrqkp` (`enabled`),
  KEY `idx_kndqmxkrszagvwwyxlnsdrlyywqzbqcpiphb` (`uri`,`siteId`),
  CONSTRAINT `fk_csjizhdzgplytfwvmsvqikobfznzpqglnxke` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xbaowdwjwypusdcvuxssbabjuxufeumduptt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gjgwpauuaedyhyubcktyuxgaidwneirshzid` (`postDate`),
  KEY `idx_qdnupnkgwqkxttmnuhhjvbjuvtzyuqzygmdg` (`expiryDate`),
  KEY `idx_isgpsbfovpozeysdlvmyqmlemribaypwqups` (`sectionId`),
  KEY `idx_nsdenzhqfogdiigqvtxnpmgugxrriwocistr` (`typeId`),
  KEY `idx_opsediijejqsqgufejrkwhsyfbvavvolusdg` (`primaryOwnerId`),
  KEY `idx_zjmekzkpefkctrslhqorgsrfdhjgdufsnszl` (`fieldId`),
  KEY `fk_etgrwhatjsghkjkodwvffnbrvcnbmkbehypk` (`parentId`),
  CONSTRAINT `fk_enugdvcysfpcilnedwcbhiepbicighgreijc` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_etgrwhatjsghkjkodwvffnbrvcnbmkbehypk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ojlmywopbrelgszfonxhmptvarbgjegrzudw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sfyabzxnhshftxghxfprjnhulvixnnisryfu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvrjpxyfvmtkwdereypryjihilcseyqlkjte` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zkvmtuajcgxdwpejpewnonspozhgmvmghzbj` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_nvxurxopnyzpztkzridswouddaigwocstaoy` (`authorId`),
  KEY `idx_tvpepnwyxomgbltbyedzixdlcnwqatonmobl` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_brgkfivcylmrrsfurgiwnllorcnzzxgykwxe` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ggkidxnzoibzkdlpgczbestctjgyqbljhmhm` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vtyisrnctosiulxlqkmuivxqbxevkoyytbid` (`fieldLayoutId`),
  KEY `idx_hjjyvwqdipufwicuhizpappbvdebougnlzxm` (`dateDeleted`),
  CONSTRAINT `fk_vksvgtxovfwxjtjxxzckjfwmphudelofexlx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_thfsceqkalzoarhztcqgzbvltlepnupfocxq` (`dateDeleted`),
  KEY `idx_gbemmxxnfihhipmkryoplwpckfkunuujtaqb` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cepzpnqcodhluxvbhgfcxwlfbtnfvkywicol` (`handle`,`context`),
  KEY `idx_dfkaywrewijltzznafockzunsvjrczsfzspq` (`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_svocgtuutxacqeydiiipbfaqfnojqzocfark` (`name`),
  KEY `idx_rbwwswfbbwxjlptlzsqezjngleodgemuyvll` (`handle`),
  KEY `idx_dzoazlsslsjtyzsqbweeqypcplkrgofynqyo` (`fieldLayoutId`),
  KEY `idx_wsfenjdjgsgcshnaaqsjolmsiofoqidptylz` (`sortOrder`),
  CONSTRAINT `fk_ihuflwzaykagfjrvqbvxyjejokwjpatmqhwk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_irpfutocelmtaqfpindqchvjsghsvrxgprvd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lspuvfpmjrofvdrvmqesqgxolyfbhmhftkmk` (`accessToken`),
  UNIQUE KEY `idx_jlvdabhlqzeassmczoocabgwhrrygjguyfqt` (`name`),
  KEY `fk_immmjqgdrlypudiludxpwsknauvsqqsovfsg` (`schemaId`),
  CONSTRAINT `fk_immmjqgdrlypudiludxpwsknauvsqqsovfsg` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kszcpnkirmfobcapnrcksxerziqxznqohawu` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aqqctuvyoyybziievvgfmskasqxxdagveuso` (`name`),
  KEY `idx_mbayyfmwtvgcvtxkbfdoxceuhoewlgpmiehr` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gfnsvcieriapmjnascgboustilsmacnsbloi` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tubjcrevhoeqwijrcknhboxrlmiijjbagouq` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_qgiyvydpltcebvpucokotfzgucjtmojfjvkt` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_wzkagglawsfusbemtrlrxjyahalgglidctae` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hcxgxqprmnfdptnshfkxfbhttigycyjszosx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ejekmdbktjbxztsbfbcafynynwmkoswmbqrs` (`sourceId`),
  KEY `idx_gwgbcdcoeqmboaqzltiayiduaqeosknqftaq` (`targetId`),
  KEY `idx_gjuntemyxgusdqjlmpwejkvdonqjxdcqgose` (`sourceSiteId`),
  CONSTRAINT `fk_imoqoyuztsaiyluyttlojypjjhywxfjapodf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_phjcrfgpjuorderdrkamrusprdkrqotymgop` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zwasphbyhazaytnmaovbdkkebowtwiadrnrc` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_igbdoaxafrxohnypfljimljnftxlglzminqj` (`canonicalId`,`num`),
  KEY `fk_ekgijdpaettfysqjoblbmdsjfekxjvkeklwq` (`creatorId`),
  CONSTRAINT `fk_ekgijdpaettfysqjoblbmdsjfekxjvkeklwq` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sgakopgyevmapussmgglclqqzeegojbedwie` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_smtgjzcjgnzlizjncayghvlcafnmqwnhxmsz` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lrqmpmznzuncqcjlwpqhwhkovksocnfjmcvq` (`handle`),
  KEY `idx_oedgoagpvumsbvgkjesgclfnbysnydaeyzxj` (`name`),
  KEY `idx_kmiuqiqiynggzxwkvjzdkcwxokvjedfpumto` (`structureId`),
  KEY `idx_ywodstifvgwhjomrgusklxgktaxpplspcbxk` (`dateDeleted`),
  CONSTRAINT `fk_iofktmwieolhdvgcogyhfyuaopwpntmoaosj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_pqgndoizifjbtiyeubbzfcviznizozclsoiq` (`typeId`),
  CONSTRAINT `fk_cottbvyunkwyklnidrlktepwkwphpuhootho` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pqgndoizifjbtiyeubbzfcviznizozclsoiq` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_clwtaprmugbgvcsbfxfqtgfpbtzxetmuecft` (`sectionId`,`siteId`),
  KEY `idx_hmpdkpklegixixaaldxihrgpnqloqsrivxpb` (`siteId`),
  CONSTRAINT `fk_omaaqjqsqckzddptxhfnhnwouylpamnnbmws` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubhfdmgrjddjismgpkdbsknikvwvtrmxfurq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ckjqxihwyyvzooohxfojjjpwyhbocrgdzaou` (`uid`),
  KEY `idx_eughrghoytiztacurxthzihfvqchqwekmshn` (`token`),
  KEY `idx_fpbgqwgvflbjhhanphquwyvmiapukdjblwpl` (`dateUpdated`),
  KEY `idx_apoulpomrrbnacdagibnxyzsbhiujnmeosur` (`userId`),
  CONSTRAINT `fk_amkwpzfirwdmktgjgzwvpllhltjssesgwaet` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdajfpuukgigmwatprvsuucvcwcsofrmawwv` (`userId`,`message`),
  CONSTRAINT `fk_ffgncunfylacvjlblhdhneyhheuofinnqacf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uehvvgjbpxrhkjciyyjxkkjzcphreyxtmbaf` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ectjzpermfobgzrgiqdwbrjolgisovfklvua` (`dateDeleted`),
  KEY `idx_qgzpxptxzregcnvmtkpikyvafnkcojqkgmkt` (`handle`),
  KEY `idx_twwclxlultlfstwmsgecgbiaavkjgopmaqaw` (`sortOrder`),
  KEY `fk_zllmzdztwevogqogdxuqifsojekkyezrgdjv` (`groupId`),
  CONSTRAINT `fk_zllmzdztwevogqogdxuqifsojekkyezrgdjv` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dffiltcqgpimscnwyxjiwsxegynyznazaegq` (`structureId`,`elementId`),
  KEY `idx_rfnftbygctsccxgaooaizeshxhmhajsnmtfp` (`root`),
  KEY `idx_jxwlnsluavahouwieqqpmsqblahhrughxqpd` (`lft`),
  KEY `idx_klmldkejlxcmldbmpsdrkyytqqlqyzkdibkg` (`rgt`),
  KEY `idx_ffynwgfxgebqfymvgbiubdioakqcibjsovnl` (`level`),
  KEY `idx_rwtvaykbeinrlczmjkkrzaybhaddrjektrdw` (`elementId`),
  CONSTRAINT `fk_xltinonhfuokapcguppdhvyejmgkgqulhdzz` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sopqjjnlwdaxgiipyatgrlhhhumcgvvhfxbn` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ctxvzgootclarupyxmifuuvvjgskhjhwcgcc` (`key`,`language`),
  KEY `idx_yhrtipsirstecwdoivhlidszkuknfjvprytt` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bancwojldxszivyqnlokbjdgviwxtqxipacn` (`name`),
  KEY `idx_pnahemzpbksweuvmahmjekmfsdzmlcnjzill` (`handle`),
  KEY `idx_qzutrayhyrdnpzvmavpwfazfekrrrhmpsdmx` (`dateDeleted`),
  KEY `fk_vfnvxpyqhdgfcvdeozrfsfmotelsoqtzfvjz` (`fieldLayoutId`),
  CONSTRAINT `fk_vfnvxpyqhdgfcvdeozrfsfmotelsoqtzfvjz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_krilfwuqpavnntmkmwudllagrbnblnjqetyj` (`groupId`),
  CONSTRAINT `fk_jetfxdvocvvgudafyrsygkjfjzzntqzahhde` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jvkvpvqsdcdjsyfffyqbgtsdxefzfqsnnufb` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pdyzwckubfqlejbwhgygyifgiwmywnqmidkk` (`token`),
  KEY `idx_kakgdwoqpqyrdmudcolkogooywbnmgfxeuiv` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ugezpwqwpwfvpkaumhrjdivwbbdcflhlqaqf` (`handle`),
  KEY `idx_fsaqeenzmqkpmqcatumjvbnflibiftloonfz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hdfgazigamoqqjhmnpfbnqwdliebditcjnuk` (`groupId`,`userId`),
  KEY `idx_ghknmypiwbwuarsicslwhabzrabzqfiqmjbv` (`userId`),
  CONSTRAINT `fk_fjcvaajzciatyjiirosddwolvhredwfmohcy` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xftsvgnhluyyfgkuzbctbhqyubgzhtjfpohz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oqhguwxjvypwihhklmsswjpunzrpfidswzui` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pmpgprcbplmkgmltwyrstjactjhddojslvol` (`permissionId`,`groupId`),
  KEY `idx_zoitfyntokxxjjtjknwcwdusydiogrnjpgjc` (`groupId`),
  CONSTRAINT `fk_aojythwcixmwbbxtambkvfxdqhnqleqglmji` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tuhxogyrusixgdtktapkqtpuprvzxjwtrhfe` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iunwddpmgeheexqsgxatlqclumyaiqaanvzo` (`permissionId`,`userId`),
  KEY `idx_sumelwivlbfdlofkgxaikqifmskbemsmahoe` (`userId`),
  CONSTRAINT `fk_bpzsedsmyxscqygyqonfgakmjcjaqonphfjh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lkfifpkjfjxpvbkjgdvkjvpxkffvfgfsropv` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_fzwerfqaqbaelmksoxxingysposuwrhrcwkp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qpqszmrlszsuiufcsdlebwfmmsjdawlizhpl` (`active`),
  KEY `idx_eqpsuoafooyyfrimicazwdpwvqrceguvvfnt` (`locked`),
  KEY `idx_jvbllwuxohhgtnbllduvwanhgvqgmulwgpqb` (`pending`),
  KEY `idx_jpbagsdpmavlklssvtmuqrzckxxqmaweyylc` (`suspended`),
  KEY `idx_jcnuutqxqopbuzrzrhfaoiwucwitmjgojyyh` (`verificationCode`),
  KEY `idx_afisptjlyboazwjscmmghwllsknktkzcjjbq` (`email`),
  KEY `idx_rgfjerycvugvbfwsyekeznrqccxdbhhawjco` (`username`),
  KEY `fk_hqkryxcvyghxafraonemohylgvqlykhgcxyd` (`photoId`),
  CONSTRAINT `fk_gopkuyvhjvckvopkyeisxidrdvifqjtkmzae` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hqkryxcvyghxafraonemohylgvqlykhgcxyd` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_spntkosvmtdhruapvcqjkvnhqsncovvtchlv` (`name`,`parentId`,`volumeId`),
  KEY `idx_qyhaajanmejmagiqyatihhsdmesdnpepzkwc` (`parentId`),
  KEY `idx_kayoemjlswmeeyqqvhclghweuoycdgzuczqg` (`volumeId`),
  CONSTRAINT `fk_khglamgdnjyurlbgaptzeypvthxcsrycdwiz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pjpysowrrrqscehrtuuubmtqzssxtfwobcug` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vfeaudxvdmnygzowfbbargkldnerblcaqxry` (`name`),
  KEY `idx_umcfmdhwczyazucujuylgiuftqdwtvroscoe` (`handle`),
  KEY `idx_cvgfcxxllwspgunwlkrdkelpjtmqixebowlw` (`fieldLayoutId`),
  KEY `idx_dymybivdqnmiqrzacnlwnvewtpefagiychhi` (`dateDeleted`),
  CONSTRAINT `fk_drejcozhgfmvendthwuqdtyhkghhjejfwdxd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hxnnlilwfhewynzrhrbhwhjivcrhtyvqqwwu` (`userId`),
  CONSTRAINT `fk_hxnnlilwfhewynzrhrbhwhjivcrhtyvqqwwu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tvwpxyqojivgqeulxnjpmnvbftkzstyrjech` (`userId`),
  CONSTRAINT `fk_lfzhhmwjasxfhspsoxmqpndmoyzgrzpcdxjb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21  2:41:24
-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES
(7,1,'postDate','2024-06-20 22:08:55',0,5),
(7,1,'slug','2024-06-20 22:08:55',0,5),
(7,1,'title','2024-06-20 22:08:55',0,5),
(7,1,'uri','2024-06-20 22:08:55',0,5),
(9,1,'postDate','2024-06-20 22:09:10',0,5),
(9,1,'slug','2024-06-20 22:09:10',0,5),
(9,1,'title','2024-06-20 22:09:10',0,5),
(9,1,'uri','2024-06-20 22:09:10',0,5),
(13,1,'postDate','2024-06-20 22:09:20',0,5),
(13,1,'slug','2024-06-20 22:09:17',0,5),
(13,1,'title','2024-06-20 22:09:17',0,5),
(13,1,'uri','2024-06-20 22:09:17',0,5);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES
(1,NULL,5,0,'First draft',NULL,0,NULL,0),
(4,NULL,5,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES
(7,5,1,NULL,'save','2024-06-20 22:08:55'),
(9,5,1,NULL,'save','2024-06-20 22:09:14'),
(13,5,1,NULL,'save','2024-06-20 22:09:20');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,NULL,NULL,'97abf6c5-cf43-4c1f-a2dc-37e30b00eabd'),
(2,1,NULL,1,4,'craft\\elements\\Entry',1,0,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,NULL,NULL,'ad04b435-77d3-42b3-b2fd-c51b3fb3b171'),
(3,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,NULL,NULL,'b408994a-f676-4eaa-803d-262adedf491b'),
(4,3,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,NULL,NULL,'da422352-1411-4c25-9edf-880be55d9893'),
(5,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,NULL,NULL,'2f340975-6f56-41dd-8653-463e5c3170e3'),
(6,NULL,1,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-20 22:08:46','2024-06-20 22:08:46',NULL,NULL,NULL,'5c507c02-3f6f-4969-ba80-d449f2a446a4'),
(7,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-20 22:08:46','2024-06-20 22:08:55',NULL,NULL,NULL,'6fe82784-06e4-485c-b4b8-cb2078b701ac'),
(8,7,NULL,3,3,'craft\\elements\\Entry',1,0,'2024-06-20 22:08:55','2024-06-20 22:08:55',NULL,NULL,NULL,'446c60b7-7da7-4da4-ab5d-6b0c48715d72'),
(9,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:02','2024-06-20 22:09:14',NULL,NULL,NULL,'077b2d87-a8bf-427f-960e-c44c611274ce'),
(10,NULL,4,NULL,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:02','2024-06-20 22:09:02',NULL,NULL,NULL,'b88b7ded-775d-4fa0-8d3c-a70c7e5930f9'),
(11,9,NULL,4,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:10','2024-06-20 22:09:10',NULL,NULL,NULL,'d7973fa9-036c-4271-9982-f142460327f4'),
(12,9,NULL,5,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:14','2024-06-20 22:09:14',NULL,NULL,NULL,'601153a0-61ff-4e4a-bdae-569178619bc8'),
(13,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:14','2024-06-20 22:09:20',NULL,NULL,NULL,'06b8e937-327d-40eb-9354-1ff00683e3e6'),
(14,13,NULL,6,2,'craft\\elements\\Entry',1,0,'2024-06-20 22:09:20','2024-06-20 22:09:20',NULL,NULL,NULL,'e83c76ea-4010-4d1d-bafb-0f6ea7c97e83');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES
(1,1,1,'Homepage','homepage','__home__',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','626f75a6-e201-4066-a306-41ebb1f869dd'),
(2,2,1,'Homepage','homepage','__home__',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','1377b8ff-5c0f-4f80-8834-79472852dcd7'),
(3,3,1,'Example Single','example-single','example-single',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','9152560c-7de4-48c5-9e36-d8c9f73de2aa'),
(4,4,1,'Example Single','example-single','example-single',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','358a7a7b-aa36-423f-b113-92db04d802ec'),
(5,5,1,NULL,NULL,NULL,NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','ccbefa3f-25c2-42bf-88b2-86cec93e4941'),
(6,6,1,NULL,'__temp_ngpbxpznpboxefhgnodighvlmbaturphwdoc','example-channel/__temp_ngpbxpznpboxefhgnodighvlmbaturphwdoc',NULL,1,'2024-06-20 22:08:46','2024-06-20 22:08:46','c821d7fe-0c37-4341-add7-91d3092913e4'),
(7,7,1,'Example Channel Entry','example-channel-entry','example-channel/example-channel-entry',NULL,1,'2024-06-20 22:08:46','2024-06-20 22:08:55','b3b570fb-cc9c-4181-bbe8-35532bb8171c'),
(8,8,1,'Example Channel Entry','example-channel-entry','example-channel/example-channel-entry',NULL,1,'2024-06-20 22:08:55','2024-06-20 22:08:55','bb66de2b-8ce5-4e83-8e6e-b36a9fc56d02'),
(9,9,1,'Example Structure Level 1 Entry','example-structure-level-1-entry','example-structure/example-structure-level-1-entry',NULL,1,'2024-06-20 22:09:02','2024-06-20 22:09:10','bb18ee4f-86d5-4ed4-be28-ea5c4ceb0154'),
(10,10,1,NULL,'__temp_pqiemnyzbbkrprkdvvbtnescikngjvrzvoth','example-structure/__temp_pqiemnyzbbkrprkdvvbtnescikngjvrzvoth',NULL,1,'2024-06-20 22:09:02','2024-06-20 22:09:02','3afc1c65-c064-45e7-83f1-b0755a31238b'),
(11,11,1,'Example Structure Level 1 Entry','example-structure-level-1-entry','example-structure/example-structure-level-1-entry',NULL,1,'2024-06-20 22:09:10','2024-06-20 22:09:10','5b847106-9c85-4f62-a3cb-1fb2285fe4e9'),
(12,12,1,'Example Structure Level 1 Entry','example-structure-level-1-entry','example-structure/example-structure-level-1-entry',NULL,1,'2024-06-20 22:09:14','2024-06-20 22:09:14','a04a5c15-dc13-4a4f-a958-5186daf7c55c'),
(13,13,1,'Example Structure Level 2 Entry','example-structure-level-2-entry','example-structure/example-structure-level-2-entry',NULL,1,'2024-06-20 22:09:14','2024-06-20 22:09:20','d3a7f364-99a0-4a36-921e-0da7c90ced68'),
(14,14,1,'Example Structure Level 2 Entry','example-structure-level-2-entry','example-structure/example-structure-level-2-entry',NULL,1,'2024-06-20 22:09:20','2024-06-20 22:09:20','1f6b3b7a-1601-45f7-9a12-9bc0e6132a27');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES
(1,1,NULL,NULL,NULL,4,'2024-06-20 22:00:00',NULL,NULL,'2024-06-20 22:00:36','2024-06-20 22:00:36'),
(2,1,NULL,NULL,NULL,4,'2024-06-20 22:00:00',NULL,NULL,'2024-06-20 22:00:36','2024-06-20 22:00:36'),
(3,2,NULL,NULL,NULL,1,'2024-06-20 22:00:00',NULL,NULL,'2024-06-20 22:00:36','2024-06-20 22:00:36'),
(4,2,NULL,NULL,NULL,1,'2024-06-20 22:00:00',NULL,NULL,'2024-06-20 22:00:36','2024-06-20 22:00:36'),
(6,4,NULL,NULL,NULL,3,'2024-06-20 22:08:46',NULL,NULL,'2024-06-20 22:08:46','2024-06-20 22:08:46'),
(7,4,NULL,NULL,NULL,3,'2024-06-20 22:08:00',NULL,NULL,'2024-06-20 22:08:46','2024-06-20 22:08:55'),
(8,4,NULL,NULL,NULL,3,'2024-06-20 22:08:00',NULL,NULL,'2024-06-20 22:08:55','2024-06-20 22:08:55'),
(9,3,NULL,NULL,NULL,2,'2024-06-20 22:09:00',NULL,NULL,'2024-06-20 22:09:02','2024-06-20 22:09:10'),
(10,3,NULL,NULL,NULL,2,'2024-06-20 22:09:02',NULL,NULL,'2024-06-20 22:09:02','2024-06-20 22:09:02'),
(11,3,NULL,NULL,NULL,2,'2024-06-20 22:09:00',NULL,NULL,'2024-06-20 22:09:10','2024-06-20 22:09:10'),
(12,3,NULL,NULL,NULL,2,'2024-06-20 22:09:00',NULL,NULL,'2024-06-20 22:09:14','2024-06-20 22:09:14'),
(13,3,NULL,NULL,NULL,2,'2024-06-20 22:09:00',NULL,NULL,'2024-06-20 22:09:14','2024-06-20 22:09:20'),
(14,3,NULL,NULL,NULL,2,'2024-06-20 22:09:00',NULL,NULL,'2024-06-20 22:09:20','2024-06-20 22:09:20');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES
(6,5,1),
(7,5,1),
(8,5,1),
(9,5,1),
(10,5,1),
(11,5,1),
(12,5,1),
(13,5,1),
(14,5,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES
(1,1,'Example Single Entry Type','exampleSingleEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'e028dd6d-44ee-41f5-b575-4921ba562311'),
(2,2,'Example Structure Entry Type','exampleStructureEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f'),
(3,3,'Example Channel Entry Type','exampleChannelEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'95ef0b64-7fa5-4a78-96c8-54053c025f38'),
(4,4,'Homepage','homepage','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'721b2b6e-f75a-4e5b-9b43-0de469c9dbb4');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"09bea70c-0a4c-4de6-a816-955967737fb0\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"6f91d278-2c6f-4a03-9665-ba57e9afad90\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'f4d041e1-3b65-4df6-9cf8-1d935a7e778a'),
(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"e61acb8a-41ef-405c-abd1-61d4f74c4a54\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"11263d96-3f07-4eb3-8d6a-742709a84a47\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'0072b5a5-fa19-442b-a142-b708534fc1e3'),
(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"6e00185e-96a3-40d7-b92d-d06871aa709c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"5f72b360-b910-4b9f-91ba-41dfaa2fcc6e\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'19ffc8b9-bed0-4915-8302-4daf927de65b'),
(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2b4376eb-29f2-4c76-ae26-74aa30213bf4\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"1211497e-ee4f-482a-bab6-02ccb36fe0d6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'fba726e9-ea21-4da8-b7ef-57dcd88e4b33');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES
(1,'Public Schema','[\"sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78:read\", \"sections.f527f66e-862e-4c16-8439-cdb3e1f894c3:read\", \"sections.87840c86-d676-4511-96cf-bc39bd159b64:read\", \"sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32:read\", \"sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117:read\"]',1,'2024-06-20 22:00:36','2024-06-20 22:00:36','83a107ea-357d-4836-b525-14319446f05c');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqltokens` VALUES
(1,'Public Token','__PUBLIC__',1,NULL,'2024-06-21 02:01:06',NULL,'2024-06-20 22:02:29','2024-06-21 02:01:06','58764bf2-bb9d-4654-a3cf-d457d1be46ba');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES
(1,'5.2.3','5.0.0.21',0,'avxabhrlbgzo','3@gsxjmfmaiu','2024-06-20 22:00:35','2024-06-20 22:08:37','7140788a-c2ee-4e26-97a1-a31eca6f3f9b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','01166f09-43d2-4d39-afb3-52c1e36fb710'),
(2,'craft','m221101_115859_create_entries_authors_table','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','7b0169ce-250b-46eb-ba30-9e994329d03c'),
(3,'craft','m221107_112121_add_max_authors_to_sections','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','15d70f86-6163-4c01-ac77-b23ce160d9f0'),
(4,'craft','m221205_082005_translatable_asset_alt_text','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','340e800e-7725-4283-9166-a155ee591bb2'),
(5,'craft','m230314_110309_add_authenticator_table','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','6471cc59-c56e-409c-a0f4-e17598ed92d7'),
(6,'craft','m230314_111234_add_webauthn_table','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','5db47736-82a8-4006-858a-334c5b3d9b78'),
(7,'craft','m230503_120303_add_recoverycodes_table','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','a0dba0fa-4ae5-40e7-a927-09c2b6f441e3'),
(8,'craft','m230511_000000_field_layout_configs','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','1773c6bb-6ec8-4767-9541-652b5e9f6c88'),
(9,'craft','m230511_215903_content_refactor','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','f3de5d96-2685-4554-9595-3946c109f55d'),
(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','3f8ffe3e-926b-4298-8c07-7e8013f03c30'),
(11,'craft','m230524_000001_entry_type_icons','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','58d8e2b9-2b29-4f1f-a2f2-d6b5d5d3c3cb'),
(12,'craft','m230524_000002_entry_type_colors','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','80e0cc2b-e7c9-4064-87a9-70b3b10212df'),
(13,'craft','m230524_220029_global_entry_types','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','c6efb345-840c-41d9-b692-4d35f950abc7'),
(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','167570a4-fe92-4827-8f0c-6d937454c134'),
(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','165ee723-8c4e-41f7-b9f8-cf29f5b4d42a'),
(16,'craft','m230616_173810_kill_field_groups','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','2c058ffc-296b-4338-9a6a-a0e0ab094793'),
(17,'craft','m230616_183820_remove_field_name_limit','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','3780ec31-0011-4f64-861e-4f10c4d0b9c1'),
(18,'craft','m230617_070415_entrify_matrix_blocks','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','453ed702-fceb-4e79-8307-2f47b3fa5291'),
(19,'craft','m230710_162700_element_activity','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','5b3efe6a-b08f-4204-a1d7-25708a800ea5'),
(20,'craft','m230820_162023_fix_cache_id_type','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','b5bef314-c9ea-4528-a8a2-e1cce36c77ee'),
(21,'craft','m230826_094050_fix_session_id_type','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','89e2f308-4c7d-465b-896e-b9459a08ea50'),
(22,'craft','m230904_190356_address_fields','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','0bc25ef6-b5e2-4694-ba72-4b3c02e4e623'),
(23,'craft','m230928_144045_add_subpath_to_volumes','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','8abceb08-1bcd-4a65-bb7a-9e79a0ca32a7'),
(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','512821c1-ac48-479a-8ff1-c40a4d25bdd9'),
(25,'craft','m231213_030600_element_bulk_ops','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','b89ffee5-682b-4761-8f2b-ad6914d52b82'),
(26,'craft','m240129_150719_sites_language_amend_length','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','9758ef9d-0937-47ee-8d66-dd293c4c288d'),
(27,'craft','m240206_035135_convert_json_columns','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','770a424a-e526-4bfc-b4a9-0156e067d779'),
(28,'craft','m240207_182452_address_line_3','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','fc59953d-fbbf-4228-a20b-5473ab7597f3'),
(29,'craft','m240302_212719_solo_preview_targets','2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-20 22:00:37','2c4598b8-d8ed-45df-8521-b27f4f834c93'),
(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-06-20 22:01:31','2024-06-20 22:01:31','2024-06-20 22:01:31','e31130e1-8c3e-4144-a7f4-25c93d78d57b');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES
('dateModified','1718921087'),
('email.fromEmail','\"olets@olets.dev\"'),
('email.fromName','\"astro-craftcms\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.color','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elementCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocomplete','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocorrect','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.class','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.disabled','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.elementCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.id','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.includeInCards','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.inputType','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.instructions','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.label','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.max','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.min','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.name','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.orientation','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.placeholder','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.readonly','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.requirable','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.size','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.step','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.tip','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.title','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.uid','\"1211497e-ee4f-482a-bab6-02ccb36fe0d6\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.userCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.warning','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.width','100'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.name','\"Content\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.uid','\"2b4376eb-29f2-4c76-ae26-74aa30213bf4\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.userCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.handle','\"homepage\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.hasTitleField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.icon','\"\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.name','\"Homepage\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.showSlugField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.showStatusField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.slugTranslationKeyFormat','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.slugTranslationMethod','\"site\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleFormat','\"\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleTranslationKeyFormat','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleTranslationMethod','\"site\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.color','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elementCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocomplete','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocorrect','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.class','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.disabled','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.elementCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.id','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.includeInCards','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.inputType','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.instructions','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.label','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.max','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.min','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.name','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.orientation','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.placeholder','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.readonly','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.requirable','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.size','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.step','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.tip','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.title','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.uid','\"5f72b360-b910-4b9f-91ba-41dfaa2fcc6e\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.userCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.warning','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.width','100'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.name','\"Content\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.uid','\"6e00185e-96a3-40d7-b92d-d06871aa709c\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.userCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.handle','\"exampleChannelEntryType\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.hasTitleField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.icon','\"\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.name','\"Example Channel Entry Type\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.showSlugField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.showStatusField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.slugTranslationKeyFormat','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.slugTranslationMethod','\"site\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleFormat','\"\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleTranslationKeyFormat','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleTranslationMethod','\"site\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.color','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elementCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocomplete','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocorrect','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.class','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.disabled','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.elementCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.id','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.includeInCards','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.inputType','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.instructions','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.label','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.max','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.min','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.name','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.orientation','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.placeholder','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.readonly','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.requirable','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.size','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.step','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.tip','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.title','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.uid','\"6f91d278-2c6f-4a03-9665-ba57e9afad90\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.userCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.warning','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.width','100'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.name','\"Content\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.uid','\"09bea70c-0a4c-4de6-a816-955967737fb0\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.userCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.handle','\"exampleSingleEntryType\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.hasTitleField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.icon','\"\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.name','\"Example Single Entry Type\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.showSlugField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.showStatusField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.slugTranslationKeyFormat','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.slugTranslationMethod','\"site\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleFormat','\"\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleTranslationKeyFormat','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleTranslationMethod','\"site\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.color','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elementCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocomplete','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocorrect','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.class','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.disabled','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.elementCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.id','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.includeInCards','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.inputType','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.instructions','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.label','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.max','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.min','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.name','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.orientation','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.placeholder','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.readonly','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.requirable','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.size','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.step','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.tip','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.title','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.uid','\"11263d96-3f07-4eb3-8d6a-742709a84a47\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.userCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.warning','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.width','100'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.name','\"Content\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.uid','\"e61acb8a-41ef-405c-abd1-61d4f74c4a54\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.userCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.handle','\"exampleStructureEntryType\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.hasTitleField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.icon','\"\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.name','\"Example Structure Entry Type\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.showSlugField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.showStatusField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.slugTranslationKeyFormat','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.slugTranslationMethod','\"site\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleFormat','\"\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleTranslationKeyFormat','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleTranslationMethod','\"site\"'),
('graphql.publicToken.enabled','true'),
('graphql.publicToken.expiryDate','null'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.isPublic','true'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.name','\"Public Schema\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.0','\"sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.1','\"sections.f527f66e-862e-4c16-8439-cdb3e1f894c3:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.2','\"sections.87840c86-d676-4511-96cf-bc39bd159b64:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.3','\"sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.4','\"sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117:read\"'),
('meta.__names__.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78','\"ssg-astro-craftcms\"'),
('meta.__names__.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32','\"Example Channel\"'),
('meta.__names__.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4','\"Homepage\"'),
('meta.__names__.83a107ea-357d-4836-b525-14319446f05c','\"Public Schema\"'),
('meta.__names__.863cff4f-f659-488d-9614-5d2b915a50ee','\"astro-craftcms\"'),
('meta.__names__.87840c86-d676-4511-96cf-bc39bd159b64','\"Homepage\"'),
('meta.__names__.95ef0b64-7fa5-4a78-96c8-54053c025f38','\"Example Channel Entry Type\"'),
('meta.__names__.b34ffb6b-3496-4a01-a7b4-92e89cc74117','\"Example Structure\"'),
('meta.__names__.e028dd6d-44ee-41f5-b575-4921ba562311','\"Example Single Entry Type\"'),
('meta.__names__.f527f66e-862e-4c16-8439-cdb3e1f894c3','\"Example Single\"'),
('meta.__names__.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f','\"Example Structure Entry Type\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.defaultPlacement','\"end\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.enableVersioning','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.entryTypes.0','\"95ef0b64-7fa5-4a78-96c8-54053c025f38\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.handle','\"exampleChannel\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.maxAuthors','1'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.name','\"Example Channel\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.propagationMethod','\"all\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-channel/{slug}\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.type','\"channel\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.defaultPlacement','\"end\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.enableVersioning','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.entryTypes.0','\"721b2b6e-f75a-4e5b-9b43-0de469c9dbb4\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.handle','\"homepage\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.maxAuthors','1'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.name','\"Homepage\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.propagationMethod','\"all\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"__home__\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.type','\"single\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.defaultPlacement','\"end\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.enableVersioning','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.entryTypes.0','\"fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.handle','\"exampleStructure\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.maxAuthors','1'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.name','\"Example Structure\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.propagationMethod','\"all\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-structure/{slug}\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.structure.maxLevels','null'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.structure.uid','\"c72b261c-2184-4610-b38e-84dc3cdfce9d\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.type','\"structure\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.defaultPlacement','\"end\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.enableVersioning','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.entryTypes.0','\"e028dd6d-44ee-41f5-b575-4921ba562311\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.handle','\"exampleSingle\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.maxAuthors','1'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.name','\"Example Single\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.propagationMethod','\"all\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-single\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.type','\"single\"'),
('siteGroups.863cff4f-f659-488d-9614-5d2b915a50ee.name','\"astro-craftcms\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabled','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.handle','\"default\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.language','\"en-US\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.name','\"ssg-astro-craftcms\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.primary','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.siteGroup','\"863cff4f-f659-488d-9614-5d2b915a50ee\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.sortOrder','1'),
('system.edition','\"solo\"'),
('system.live','true'),
('system.name','\"astro-craftcms\"'),
('system.schemaVersion','\"5.0.0.21\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.require2fa','false'),
('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES
(1,1,NULL,1,NULL),
(2,3,NULL,1,NULL),
(3,7,5,1,''),
(4,9,5,1,''),
(5,9,5,2,''),
(6,13,5,1,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES
(1,'slug',0,1,' homepage '),
(1,'title',0,1,' homepage '),
(3,'slug',0,1,' example single '),
(3,'title',0,1,' example single '),
(5,'email',0,1,' changeme example com '),
(5,'firstname',0,1,''),
(5,'fullname',0,1,''),
(5,'lastname',0,1,''),
(5,'slug',0,1,''),
(5,'username',0,1,' admin '),
(6,'slug',0,1,' temp ngpbxpznpboxefhgnodighvlmbaturphwdoc '),
(6,'title',0,1,''),
(7,'slug',0,1,' example channel entry '),
(7,'title',0,1,' example channel entry '),
(9,'slug',0,1,' example structure level 1 entry '),
(9,'title',0,1,' example structure level 1 entry '),
(10,'slug',0,1,' temp pqiemnyzbbkrprkdvvbtnescikngjvrzvoth '),
(10,'title',0,1,''),
(13,'slug',0,1,' example structure level 2 entry '),
(13,'title',0,1,' example structure level 2 entry ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES
(1,NULL,'Homepage','homepage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'87840c86-d676-4511-96cf-bc39bd159b64'),
(2,NULL,'Example Single','exampleSingle','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'f527f66e-862e-4c16-8439-cdb3e1f894c3'),
(3,1,'Example Structure','exampleStructure','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'b34ffb6b-3496-4a01-a7b4-92e89cc74117'),
(4,NULL,'Example Channel','exampleChannel','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'31cbaa90-6504-4e89-87f0-d8c2ed3f5f32');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES
(1,4,1),
(2,1,1),
(3,2,1),
(4,3,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'__home__',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','ddb0932f-ec02-4491-85c2-70ec5a194b14'),
(2,2,1,1,'example-single',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','19c00743-7b37-4169-aab9-de0eeae159fd'),
(3,3,1,1,'example-structure/{slug}',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','eb79013b-9ab9-40f6-99f3-71bd512913ab'),
(4,4,1,1,'example-channel/{slug}',NULL,1,'2024-06-20 22:00:36','2024-06-20 22:00:36','c7036c51-58ee-44a4-b27c-820c8ffabf9f');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES
(1,'astro-craftcms','2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'863cff4f-f659-488d-9614-5d2b915a50ee');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES
(1,1,1,'1','ssg-astro-craftcms','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'0bda1c6b-607d-4b82-8274-4bdc4f5a2a78');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES
(1,1,NULL,1,1,8,0,'2024-06-20 22:09:02','2024-06-20 22:09:19','37342d0b-bf63-4cbb-91ec-4d18da6557f8'),
(2,1,9,1,2,5,1,'2024-06-20 22:09:02','2024-06-20 22:09:19','186a2297-f5cf-43f7-a31d-83a7211b992c'),
(3,1,10,1,6,7,1,'2024-06-20 22:09:02','2024-06-20 22:09:19','a4c46441-eb21-4301-bd8d-b50b480abea2'),
(4,1,13,1,3,4,2,'2024-06-20 22:09:14','2024-06-20 22:09:19','e8ccce7c-1183-48d1-a0be-3fd53d02b4d8');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES
(1,NULL,'2024-06-20 22:00:36','2024-06-20 22:00:36',NULL,'c72b261c-2184-4610-b38e-84dc3cdfce9d');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES
(5,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(5,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'changeme@example.com','$2y$13$fTfryZ0OretJztf0PALBnOlWVU4oS9CveIBglpMZcjlLUioyTG/Pi','2024-06-21 02:40:51',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-06-20 22:00:37','2024-06-20 22:00:37','2024-06-21 02:40:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES
(1,5,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-06-20 22:00:38','2024-06-20 22:00:38','fe8bc8a6-3e78-4bdc-b6ad-72699f124285'),
(2,5,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-06-20 22:00:38','2024-06-20 22:00:38','91a315d4-bbbc-4ba0-9579-f0fafc6ae118'),
(3,5,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-06-20 22:00:38','2024-06-20 22:00:38','9c72828e-c858-4eca-bdeb-cd4bf98e00c7'),
(4,5,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-06-20 22:00:38','2024-06-20 22:00:38','e1708eda-186f-47a2-a512-7ea82dbfe442');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21  2:41:24
