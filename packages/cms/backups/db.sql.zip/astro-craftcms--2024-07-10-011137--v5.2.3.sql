-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_fqrshzogudtunqthilyjgjgsgembylmoxhea` (`primaryOwnerId`),
  CONSTRAINT `fk_fqrshzogudtunqthilyjgjgsgembylmoxhea` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lxeyinsnlsqbzaepduzccglnuqxwypdqwqfm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ycxiqzsajqfutoaqrwgsqmrohuvycqjclunt` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_upbllpnjrgxkcbegtfocidxgdnqejomwxalh` (`dateRead`),
  KEY `fk_edswcbrcgvqjsfjztdtjpvbslpqrbgatdufj` (`pluginId`),
  CONSTRAINT `fk_edswcbrcgvqjsfjztdtjpvbslpqrbgatdufj` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_spdhlblsptxydepmrduhqfowbssoiahcwstu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hztrrjgiispawcnpabvjrvyvzxnuaugdhdaq` (`sessionId`,`volumeId`),
  KEY `idx_dljpkeczejiwwdxscgnebkqkhelaupwwtspe` (`volumeId`),
  CONSTRAINT `fk_ebrpmozvlwollyponwqkzsiidwetxeyqrkyo` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mkmoibcnvsqdxocneoqqtwcpzkxskbigszda` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_evcrmevzbchmxrreselordjkbjqwogtgdlih` (`filename`,`folderId`),
  KEY `idx_kfmugbwsrzoehrtgjirvagqtichftdxgfuin` (`folderId`),
  KEY `idx_jzntrxualcsfbydiegmxzxomijrlpvpincxs` (`volumeId`),
  KEY `fk_qarzmjniaoexphhjrmyrreyyiptqofpdxkue` (`uploaderId`),
  CONSTRAINT `fk_bqlejwmovkgnfpxqoyeqrkluubrzietftvri` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cevakxafhoyjcllrlqflqyzsowgamdtxrpmg` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qarzmjniaoexphhjrmyrreyyiptqofpdxkue` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_twdemvweatabyqyekfgaxihdkcnymgordlac` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_lzfzzsspkduyjalpagvrhhrvoeozhruabbyp` (`siteId`),
  CONSTRAINT `fk_ghypualchxzmueuhzmdbwkjgxyynerjyokbm` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lzfzzsspkduyjalpagvrhhrvoeozhruabbyp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mqlcaejfswhmyrlqsimtjydopoppuvuxlbzo` (`userId`),
  CONSTRAINT `fk_mqlcaejfswhmyrlqsimtjydopoppuvuxlbzo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jhldpxcmsomtzlyioommnebfhptbufoibgha` (`groupId`),
  KEY `fk_nfrwnxagbhwzcoybungdelwsymitbpdmkbuw` (`parentId`),
  CONSTRAINT `fk_armedddjuksqlufnxiuylemrmdutkkrpjmdp` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nfrwnxagbhwzcoybungdelwsymitbpdmkbuw` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pwwxkvcmchpbtspszgfcymriugxvhifkiwbh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sllwtjtpniolriddblzqgreeyacnmrrwcgyl` (`name`),
  KEY `idx_qkukkvnsxqhgvhqsikvunjxqvjroirxumfvj` (`handle`),
  KEY `idx_oaqwmwhysbicvwmobpylfpaldhpwcfrbpzts` (`structureId`),
  KEY `idx_autlgyqnbbeaeyxgehbqrtnvfjbhmmkrgbaa` (`fieldLayoutId`),
  KEY `idx_nhcbsqprehzrukflovqdrrvjtkkpgakqahgw` (`dateDeleted`),
  CONSTRAINT `fk_glmxptuwcyyvffvboxoesrmlzmdprsnoziut` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rpvltltbixtorecfsodgrfafxulnelgxmzir` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_egxtfgqmtxpkmjoahwqwprppmvanpdaxwrol` (`groupId`,`siteId`),
  KEY `idx_cjafqjhfvqmfbdevhnhzxixviqvwsbkjnfcm` (`siteId`),
  CONSTRAINT `fk_dwynayiafviulxxpchilnmqvdxoynbuuggts` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_phikhvdqbolslzgxexhlznyuauqulwbptuiw` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_qolydhkdemmibswfhcqdhraccmnphptzhqpz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_josdgtgmpxojztmciwqdxnilnmchhkogivvm` (`siteId`),
  KEY `fk_jghkqpvldpkmtvgigqkpidomklbxprtuwere` (`userId`),
  CONSTRAINT `fk_amxsybvumquihbrocmzfjcpaokbzoqxpbyeu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jghkqpvldpkmtvgigqkpidomklbxprtuwere` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_josdgtgmpxojztmciwqdxnilnmchhkogivvm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_dkrjwmbyvnkwsivaxqtftdrrvjxirwgpihrs` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_pnsxqbjbgiwqkdpyatysclecihteklkzbkvd` (`siteId`),
  KEY `fk_esnbkkbiqybnwdjjxgusdchkkqzmfwqzmsqx` (`fieldId`),
  KEY `fk_htbuunerjsrrwfsyrlnwckznkrfhuunxcmow` (`userId`),
  CONSTRAINT `fk_esnbkkbiqybnwdjjxgusdchkkqzmfwqzmsqx` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_htbuunerjsrrwfsyrlnwckznkrfhuunxcmow` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pnsxqbjbgiwqkdpyatysclecihteklkzbkvd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_whycmmvrphgzlbmpwtakuqcuknclogowocvj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_epaotxttjlowktybqkwqvdquxuncragrhtye` (`userId`),
  CONSTRAINT `fk_epaotxttjlowktybqkwqvdquxuncragrhtye` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_odhnofhrjdlnjbfjsfvrjtebnyiqoiivyhxx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_nhczubfaqcqwxfxdfcofvkospwjqzckxxlcx` (`creatorId`,`provisional`),
  KEY `idx_xcwdwmgljelreeyivnlibubymxkksucanmwt` (`saved`),
  KEY `fk_ozvoylzpermckszrsefcdvdpmzxgzqgqfjaj` (`canonicalId`),
  CONSTRAINT `fk_iffddyorjlhpncmgxoylidxdvgrrlfugbznk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ozvoylzpermckszrsefcdvdpmzxgzqgqfjaj` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_appvznzkjmweaehskkymknppgblfsbremljv` (`elementId`,`timestamp`,`userId`),
  KEY `fk_cliywjfswckibicxxyknyqnjnjfuoyubluoz` (`userId`),
  KEY `fk_jvhgymuxlegngpnekiqcvhbnsqxxsbwonclo` (`siteId`),
  KEY `fk_fwlgwuttggrxggxoiarmkiqgccwgbblgqyit` (`draftId`),
  CONSTRAINT `fk_cliywjfswckibicxxyknyqnjnjfuoyubluoz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fwlgwuttggrxggxoiarmkiqgccwgbblgqyit` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jvhgymuxlegngpnekiqcvhbnsqxxsbwonclo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rkcvbsfctrsxoyuhlrerjyllfiienqphepgy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_exynqewlqxxsysihqnnaiujylbhcitcdxtez` (`dateDeleted`),
  KEY `idx_yqorvyxscquswaletxfgtpiquwwpgrezcesl` (`fieldLayoutId`),
  KEY `idx_zeqyarxhqouomvlebkggsauciboirohvyvme` (`type`),
  KEY `idx_orfxtyqawhggessgopcylkdrshbhbbvzilvm` (`enabled`),
  KEY `idx_yebdttgrgwqfuxwbshjjmiwhqahczljyviml` (`canonicalId`),
  KEY `idx_xraxlzunidvgdfmrfgpgwygwawqcuaxjrxnr` (`archived`,`dateCreated`),
  KEY `idx_rqvbmuyvsaczshvkxosptnnfocrordlnwlwk` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_iotzijofquqdvyucoyaxbvabskfvrrmkusya` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_wzlexgwdtkbdiifjfvqlzpbohrazpbpdpike` (`draftId`),
  KEY `fk_btwqixjgzpmvlqrhywzarlylvbakcykobydy` (`revisionId`),
  CONSTRAINT `fk_btwqixjgzpmvlqrhywzarlylvbakcykobydy` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ibyukzqykqdsoybxfgrcpvioyumlqvcndbat` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wzlexgwdtkbdiifjfvqlzpbohrazpbpdpike` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zaheblvctqmbitdxyotxrvcurvwfmzuzhtlm` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_yeomyxyzrxmpthyrlmgpspldthuojzhtyuub` (`timestamp`),
  CONSTRAINT `fk_mjhrdsdivwzxbsqqtxncsgjkmxobdppqfiud` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_iiugcabpugdollvdroeiqvpnuxyorclpetbt` (`ownerId`),
  CONSTRAINT `fk_fygtqsexhhyomjehftxcuonqaicxkegdbtya` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iiugcabpugdollvdroeiqvpnuxyorclpetbt` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rfgqocvcbefpuarxxsejgnyzvcmurouyvmwr` (`elementId`,`siteId`),
  KEY `idx_eyxyepuxtpiuztupzljwgasccymxloqvvsfj` (`siteId`),
  KEY `idx_koxpplhpgcnlvaaxtyifjasuvdvlyjbklxdt` (`title`,`siteId`),
  KEY `idx_pwhvyyebrjcutfpvipevnlhioamupjunnreu` (`slug`,`siteId`),
  KEY `idx_pgesmatdydyhyivtzaiqvivryfdfhztlnske` (`enabled`),
  KEY `idx_wsdfdgzpnaznquqsptvbhmoojqixvavxscwp` (`uri`,`siteId`),
  CONSTRAINT `fk_rftptznyqokzmkibfeezemqzitqfspkwoazr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xnofdooxselmnxoboqslnhtjbcfdxvzpitrs` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_utucbxziwnbamzlqwgaooumgpfutjglbxtzq` (`postDate`),
  KEY `idx_dgyoeytuctckwxnahuycgjkskddklcgwjfwu` (`expiryDate`),
  KEY `idx_reazdpsdbazqgmrtpywejzzjutdtuuqzcxrx` (`sectionId`),
  KEY `idx_jtqgfpquhbmonwluuxkogaatqsdcwrqyetah` (`typeId`),
  KEY `idx_yecgitbuikyjeucjtdegrnygldiamzqklitv` (`primaryOwnerId`),
  KEY `idx_vvimyvhsfahdsfxzkzxnqwokcqpdqclzukfc` (`fieldId`),
  KEY `fk_cqqeoynpchlonitpexazrrvqpoiipmxfdikt` (`parentId`),
  CONSTRAINT `fk_bnsxlbwhfssiutdxjdxnjskwssumjttrilix` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cqqeoynpchlonitpexazrrvqpoiipmxfdikt` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emqjfrzbhfbdaddwrqgvbonwverbqfxjsruk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jdvsazaebvcudtjmtgeyuagtvhmssgiabbip` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kvedpyzzhighkyqppmorhviwfshtynnbizbh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_znohmkjjeztdxfiqljjwesoevqkqpmqixhfq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_prpcluadfdfvcwueowuyekneodskbbjbsowc` (`authorId`),
  KEY `idx_wjamqtxfxxltleqcdiofgyinygkkgdrgppzm` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_nxvmkzsynpatqxumdmeqdzsdgmfbltmlhkvg` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qcxvrbjrysiznfkqenmyzgkmqixryqsjtzyd` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usurwnsknttfevrhracztaxrcghhqndvvlxo` (`fieldLayoutId`),
  KEY `idx_yqkkfxiwevbdoahhuwhqvphfaeqrjjlzuigj` (`dateDeleted`),
  CONSTRAINT `fk_eniwapkigflbvqdnqoldnlicxjggnlbngifn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_awvnlashlplendhxyzvxzfjgjxgpxgmlquig` (`dateDeleted`),
  KEY `idx_jijjbhrizvlsvzfcmooivdjtgowcovwpgxhe` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vkqatojfxlfprguvxomxlrwduwnixqirppuj` (`handle`,`context`),
  KEY `idx_wofsomjiigzwpdyhwmgqegnvxhbzujhyqyht` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_opuznqmhhleazwzgwexadyjwphthlengjhtq` (`name`),
  KEY `idx_qexvkehyvchwsdruigywovsxkdorerbhcsyi` (`handle`),
  KEY `idx_nrtazzasxcnxofgxpzmbjvmpgjrglmxjfitt` (`fieldLayoutId`),
  KEY `idx_dgiksoeuxwrabybhsnhdkntsuojrjjzkejhf` (`sortOrder`),
  CONSTRAINT `fk_bukwvpnmthroeqeofhqyhvnsxdhcblhqhutt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdatixynldxtkitrulqgrercjibxuozxyuqt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uzeozvmtijhpernwpaivmloyictjmfkbbzju` (`accessToken`),
  UNIQUE KEY `idx_wscvnodfjlbqpdlasoyvbludofmwovysbpke` (`name`),
  KEY `fk_fjcnhxwvrlukfjctcuelbezixwufzzkfltup` (`schemaId`),
  CONSTRAINT `fk_fjcnhxwvrlukfjctcuelbezixwufzzkfltup` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qzrfvvveynjjaulpdnqynykguyppiaehsrbk` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qznqhuexonpejjtudmyesrdnlveezefshlqb` (`name`),
  KEY `idx_rfnvxgydunilhlfkmyufkscstlrrcqgskequ` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vyiupchhvirfgtxkehpumiwxyjzmyoymrexr` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tiaczhwcowujkdjukvahwxxzphvcdengkbcf` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_soxmnycvqglvhaqkdbdjprprkeskdflfywaa` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_grgvqbhbcaajivixptscypyxpvdsizoqfrzg` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bvrhhpxqxvxepcphzdpaaqrqjzfqcvpxmqzb` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_jvhwgcdrgjwpdynulpungtzeqejkjdbdgmcy` (`sourceId`),
  KEY `idx_acjbtsutuonmccahfxqibhwhqyqqwekioqsb` (`targetId`),
  KEY `idx_fghsdtihiaqmtsvmfeuljwfqcxwroxdvuuno` (`sourceSiteId`),
  CONSTRAINT `fk_eiufbkajuhdmbgnknjglnpiyvaukudwrjrau` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iembxwffibgrdmxmjzuvhfbkeiaaydxxtgps` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbgbgiaoljufmleydwtupzsicuqywonqkwfj` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mhziiedxurzmgypqrarqzojenbbvwvzcmima` (`canonicalId`,`num`),
  KEY `fk_bvdllqojhblphesjdswkdslnibkatudljobg` (`creatorId`),
  CONSTRAINT `fk_bvdllqojhblphesjdswkdslnibkatudljobg` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vpackptoafxglnhpwsannkifguusrkycgbaf` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_hllpjpwtyapgrbaaxrbwqavkszztzkqnjhbd` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rpkmqwyelnfiqgllzxatjacczudtnigbbtiz` (`handle`),
  KEY `idx_wogkthsuwnhtmguxoqwixubslipwksdvqmhe` (`name`),
  KEY `idx_brimqkrcoihuusygowbizhmqlxdgptbwkczc` (`structureId`),
  KEY `idx_hrbflrgyaethdvswvrdnctvuvksfrwfoefnu` (`dateDeleted`),
  CONSTRAINT `fk_yxjbwemzjnhfrhxznreudxjsicqlwazyqpbe` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_wpiagbzvissurvovnajdoshawwculwaiiuxf` (`typeId`),
  CONSTRAINT `fk_ofewymezarjfvczchaiefpnyusfcpdmytbps` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpiagbzvissurvovnajdoshawwculwaiiuxf` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kzqyjacrqpschmnreanknylxlmdfgbbgnaps` (`sectionId`,`siteId`),
  KEY `idx_ovycwgkmparjsualrixgpbpydpresgysdswq` (`siteId`),
  CONSTRAINT `fk_trbblvwyfnijvxsjcspvzhcioetowrplvsil` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wadigrwmsedcqzxyikmjwfvpyzikvphjumoe` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wbrorznyfxdlstwriybpasmsfvroaqvosycx` (`uid`),
  KEY `idx_ttiwfspoppqzdbvpnpxkqomkwgrfiybomjft` (`token`),
  KEY `idx_xhfwsawxpkaimncrnzxjxxcapygagocqwevu` (`dateUpdated`),
  KEY `idx_gwdoxdteedjagpozazjjyiynpdsdflriaizy` (`userId`),
  CONSTRAINT `fk_kmwgqrbonglsqullxzefnrmqttbhkczqbgio` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_luxylwcjsrpxukyrywkbwuoxkkikolpohwud` (`userId`,`message`),
  CONSTRAINT `fk_ezhwnakmvetrluogjbkdhvwswswvomynqjeq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bygwyznixrvezhgkoqiwfprjfnlpgtsmbeap` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dqcspsylxlkfmrikzscxyberijyjsoljlifc` (`dateDeleted`),
  KEY `idx_xscrinscohnorayitoqlsinzsbbhrpovfmuy` (`handle`),
  KEY `idx_uxawihqmulwdejkraqahwuhbdraewbadfrqh` (`sortOrder`),
  KEY `fk_gsvmaawjjiqbozqhvudktkhhmolhzvvqkpoo` (`groupId`),
  CONSTRAINT `fk_gsvmaawjjiqbozqhvudktkhhmolhzvvqkpoo` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hbevvxeavrokstreqsramfvumagdrrfuapat` (`structureId`,`elementId`),
  KEY `idx_korzjswqnuqdrguqrnosibumouqcsbllrheu` (`root`),
  KEY `idx_hhdwdbgaxfeefuczgyfryhbzdgqbuwztgbrh` (`lft`),
  KEY `idx_nmllassmwauigdsuxvtwpbitcfnithzlkcjq` (`rgt`),
  KEY `idx_qnagokexwzsyqpcptdcdwghmvyzqzvwlblke` (`level`),
  KEY `idx_tjcrqbiysfpalddeeokprwxcucomvpluocym` (`elementId`),
  CONSTRAINT `fk_bxdtcdzekzznzcyncttxbebuauzmmulwlkch` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_phgijqywcqgjfqcnuiyumvpuvtqaztrchbnp` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eceinbguliqqqnlmvbtbtinlsaoqxxvcfdly` (`key`,`language`),
  KEY `idx_jhkccknfccozzoqwtejhmlrkcfxnvfqipquh` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yymxephoebwpperixkqttgnokwelxergtbfl` (`name`),
  KEY `idx_rddkiqldqfodzknxpsanoeujxdrstxkgqwro` (`handle`),
  KEY `idx_plfjalqcgzsrjlozrgykguemesstjwqcquvb` (`dateDeleted`),
  KEY `fk_cvmfqqpgiwpzqeppdxzkiihjfxwbzfdvhzeo` (`fieldLayoutId`),
  CONSTRAINT `fk_cvmfqqpgiwpzqeppdxzkiihjfxwbzfdvhzeo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aqbbfkrehmwcrfzygqocqbefybkmenpdiutt` (`groupId`),
  CONSTRAINT `fk_dhcaapehcmkwtfgjjvibaadxgstumvevscwy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vvkdakbktmghvwhvvyjaqpiwmpiwbzhqxail` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_npmfvhoigxdpsebtkmavuqjbngwqfnwjvxoj` (`token`),
  KEY `idx_itssmyukmepuxjowprzrwihgsajicrqwcfbt` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sjtnygmrknhiuevpiwimdyzymdtspptygtzz` (`handle`),
  KEY `idx_heqrdnerercoxvfaircszkgulgdsbvasqngx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iwixpvabpdzzgcmmifwsdvvfsbfuxasmgvnx` (`groupId`,`userId`),
  KEY `idx_qtcgkbovlbgzesivzjovpifhfjpyhayofueg` (`userId`),
  CONSTRAINT `fk_qqxeargqkovfotlthclbypkpfyyyjystmxdk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjkwoxufexjsuzujzbcqnbzdusvlnoruhklw` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fldmmwzwdgtwpnlucesnegglivqxjkoxrbgf` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_syjrubmhrpvcitsnxomfsjegwdcciulpncdo` (`permissionId`,`groupId`),
  KEY `idx_umjdodoidcdxmureeeohbrxfayqqalenfygy` (`groupId`),
  CONSTRAINT `fk_gjctediidwzrmvoeqpfcfrbfpqhkhsbiwtde` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_unepbqdbeqzpattmppaeehuiyobcwltbhxwy` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pfivcwzhbhiywsxaulmnqiyewhwcixvjtimv` (`permissionId`,`userId`),
  KEY `idx_egzrjuoqcuhnrwartomdgbxqyqivgsltwdwn` (`userId`),
  CONSTRAINT `fk_lggdjfpxjafoeorvdfsyaifymcluvghmrcuq` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nuouaqosdriknjzeeurozklymmlwjeppjhcy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ojyfdavagjjclucofehssaaywkkdzoekeqqu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vwfkqmdtaqjofbyeiotilnwmyqapdbozxkcp` (`active`),
  KEY `idx_acitrsksfsovzduyucvcfhbwihspizvcjnao` (`locked`),
  KEY `idx_csrkslqpvyyfsuegrmhzlwfnbqgetyginthy` (`pending`),
  KEY `idx_zabsgukssgzggajqygwnutcmbwaevhdhsjoy` (`suspended`),
  KEY `idx_povxntsmhnsqmpcpfhjxkdjmtmepqrbhiitx` (`verificationCode`),
  KEY `idx_dxorqblnofoloitclcgrrvbzkcqtrkrmphsg` (`email`),
  KEY `idx_jwvzglhprprdobtnrqerbqvsfwjdqwcgttgj` (`username`),
  KEY `fk_kkmfriglsgrlcacyljcpqyluvodfbmmlhjpy` (`photoId`),
  CONSTRAINT `fk_ighnvapyzmfktwigclpbqizgxfgjecrkunma` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kkmfriglsgrlcacyljcpqyluvodfbmmlhjpy` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ntpirlpaexmonltzcrpbgbhgmkwbhvdqnjrf` (`name`,`parentId`,`volumeId`),
  KEY `idx_cawejfdnvpzhdmnnzzgbxjuoeqyscobccvqq` (`parentId`),
  KEY `idx_iqtahwxtgxspjvvxmblagxqeeiwsxazsbltc` (`volumeId`),
  CONSTRAINT `fk_gngzfmfltwmxkwicugpvhnqbrdvyyyqysphs` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpuintqrswxwqzskmthmeurrpdinkuszrxxs` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zjqmcnevncyljpbexlbyyixdoerarheesqpj` (`name`),
  KEY `idx_lhznngsodcqzvdzuudthfgmhdxaflhuyujrj` (`handle`),
  KEY `idx_wnndpennlbuqvyegwlvcwqscndigzghmjvnp` (`fieldLayoutId`),
  KEY `idx_jakbtnvmxyjjdjiuofbepgyproihwihpxsca` (`dateDeleted`),
  CONSTRAINT `fk_mvfgwbvvbyasdexbqhkiuvxhwzobpxyrbnzx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_pucgchfcqeyvhqacalvqrolupkroxzmbidlu` (`userId`),
  CONSTRAINT `fk_pucgchfcqeyvhqacalvqrolupkroxzmbidlu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_chfjlsakmxrspgreqozfttuxsptnwlahlrlk` (`userId`),
  CONSTRAINT `fk_pjvjghmjzqtyioudngmizvdpdbiogohdngaa` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10  1:11:37
-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES
(1,1,'email','2024-06-14 01:23:45',0,1),
(1,1,'lastPasswordChangeDate','2024-06-14 01:23:10',0,1),
(1,1,'password','2024-06-14 01:23:10',0,1),
(2,1,'postDate','2024-06-14 01:52:46',0,1),
(2,1,'slug','2024-06-14 02:42:54',0,1),
(2,1,'title','2024-06-14 02:25:42',0,1),
(2,1,'uri','2024-06-14 02:42:54',0,1),
(8,1,'postDate','2024-06-14 02:26:05',0,1),
(8,1,'slug','2024-06-14 02:26:04',0,1),
(8,1,'title','2024-06-14 02:26:04',0,1),
(8,1,'uri','2024-06-14 02:26:04',0,1),
(10,1,'slug','2024-06-14 02:26:20',0,1),
(10,1,'title','2024-06-14 02:26:20',0,1),
(10,1,'uri','2024-06-14 02:26:20',0,1),
(14,1,'postDate','2024-06-14 11:33:31',0,1),
(14,1,'slug','2024-06-14 11:33:31',0,1),
(14,1,'title','2024-06-14 11:33:31',0,1),
(14,1,'uri','2024-06-14 11:33:31',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES
(16,1,2,'1cdb3f23-0acd-4dee-b97c-dbb150224874','2024-07-10 00:25:24',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES
(2,NULL,1,0,'First draft',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES
(1,1,1,NULL,'save','2024-06-14 01:23:45'),
(2,1,1,NULL,'save','2024-06-14 02:42:54'),
(8,1,1,NULL,'save','2024-06-14 02:26:05'),
(10,1,1,NULL,'save','2024-06-14 02:26:23'),
(14,1,1,NULL,'save','2024-06-14 11:33:31'),
(16,1,1,NULL,'edit','2024-07-10 00:25:24'),
(16,1,1,NULL,'save','2024-07-10 00:25:24');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-06-13 21:42:33','2024-06-14 01:23:45',NULL,NULL,NULL,'a4096f0d-3019-4d19-9b28-f1229cba1349'),
(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-06-14 01:52:38','2024-06-14 02:42:54',NULL,NULL,NULL,'255ab06d-7a7a-4d97-a3f1-a34c743df91b'),
(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-06-14 01:52:46','2024-06-14 01:52:46',NULL,NULL,NULL,'7477bdd7-f5a6-4036-9c41-0452c80dd03c'),
(4,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-06-14 02:24:46','2024-06-19 19:15:26',NULL,NULL,NULL,'bc8d8b8f-e80f-4f68-abf5-9776d6ac0cc0'),
(5,4,NULL,2,2,'craft\\elements\\Entry',1,0,'2024-06-14 02:24:46','2024-06-14 02:24:46',NULL,NULL,NULL,'726a7d0d-e4af-47fa-bf32-97e01d305055'),
(6,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-06-14 02:25:42','2024-06-14 02:25:42',NULL,NULL,NULL,'3c31346b-46fe-4dca-8c61-947ae29ec782'),
(7,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2024-06-14 02:25:47','2024-06-14 02:42:38',NULL,'2024-06-14 02:42:38',NULL,'50417060-a097-45df-841e-d9955cc11906'),
(8,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-14 02:25:52','2024-06-14 02:26:05',NULL,NULL,NULL,'17ebb048-358b-4d49-aa00-46259ac4b701'),
(9,8,NULL,4,3,'craft\\elements\\Entry',1,0,'2024-06-14 02:26:05','2024-06-14 02:26:05',NULL,NULL,NULL,'0e600224-3a89-4d5a-8718-bb2bd9e5521d'),
(10,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-14 02:26:12','2024-06-14 02:26:23',NULL,NULL,NULL,'abcb986b-f85c-4873-8796-fc474b0a50b4'),
(11,10,NULL,5,3,'craft\\elements\\Entry',1,0,'2024-06-14 02:26:23','2024-06-14 02:26:23',NULL,NULL,NULL,'eb84d32d-abf8-4452-90bd-ef3642202b55'),
(12,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-06-14 02:42:40','2024-06-14 02:42:40',NULL,NULL,NULL,'aea9ee89-3d83-47aa-878a-f5a0301c8c78'),
(13,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2024-06-14 02:42:54','2024-06-14 02:42:54',NULL,NULL,NULL,'daa4382c-ab70-4ba0-a438-19ed48299c64'),
(14,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-06-14 11:33:27','2024-07-10 00:23:46',NULL,'2024-07-10 00:23:46',NULL,'f9451708-c0b5-40bc-af23-f9e4c03518e3'),
(15,14,NULL,8,1,'craft\\elements\\Entry',1,0,'2024-06-14 11:33:31','2024-06-14 11:33:31',NULL,'2024-07-10 00:23:46',NULL,'701a72d2-ef9c-4ab0-b12d-b24edf4b9872'),
(16,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-06-19 00:31:47','2024-07-10 00:25:24',NULL,NULL,NULL,'6ce42f85-46fe-4de1-87c4-0a52df95a909'),
(17,16,NULL,9,4,'craft\\elements\\Entry',1,0,'2024-06-19 00:31:47','2024-06-19 00:31:47',NULL,NULL,NULL,'2c891546-0102-4691-947e-359b7bd05617'),
(18,4,NULL,10,2,'craft\\elements\\Entry',1,0,'2024-06-19 19:14:42','2024-06-19 19:14:42',NULL,NULL,NULL,'8943c989-c434-46d7-bc20-ef54cbca503b'),
(19,4,NULL,11,2,'craft\\elements\\Entry',1,0,'2024-06-19 19:15:26','2024-06-19 19:15:26',NULL,NULL,NULL,'17888224-0606-4a92-b33f-a838e0987946'),
(20,NULL,NULL,NULL,5,'craft\\elements\\GlobalSet',1,0,'2024-06-29 04:14:58','2024-07-03 01:58:09',NULL,'2024-07-03 01:58:09',NULL,'842cf81b-481b-403d-bd40-88c87adb099b'),
(22,16,NULL,12,4,'craft\\elements\\Entry',1,0,'2024-07-10 00:25:24','2024-07-10 00:25:24',NULL,NULL,NULL,'90aeb919-4cc3-4c13-b8f0-0e4e649030ec');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES
(1,1,1,NULL,NULL,NULL,NULL,1,'2024-06-13 21:42:33','2024-06-13 21:42:33','d5f80e59-8cea-4a5f-8af6-d3526b537fe5'),
(2,2,1,'Example Channel Entry','example-channel-entry','example-channel/example-channel-entry',NULL,1,'2024-06-14 01:52:38','2024-06-14 02:42:54','0f37ecad-f993-427f-9e5d-623d528e295c'),
(3,3,1,'Example Post','example-post','posts/example-post',NULL,1,'2024-06-14 01:52:46','2024-06-14 01:52:46','0ca04d59-f3cc-4882-b440-f06f673f7d68'),
(4,4,1,'Example Single','example-single','example-single',NULL,1,'2024-06-14 02:24:46','2024-06-14 02:24:46','4bf18a01-81dd-4c7e-8026-0a8c1d56edc0'),
(5,5,1,'Example Single','example-single','example-single',NULL,1,'2024-06-14 02:24:46','2024-06-14 02:24:46','4bdcc93d-97c4-4782-a74d-b0e74910f4f8'),
(6,6,1,'Example Channel Entry','example-post','posts/example-post',NULL,1,'2024-06-14 02:25:42','2024-06-14 02:25:42','a255d6d6-9462-4b4a-b86f-4e3a501c0097'),
(7,7,1,NULL,'__temp_enucutvdvlhyxqvxzvkhifdoxmtbvlnwkaxm','example-channel/__temp_enucutvdvlhyxqvxzvkhifdoxmtbvlnwkaxm',NULL,1,'2024-06-14 02:25:47','2024-06-14 02:33:20','e47be9e7-8425-4a1a-ba08-3148112ce31a'),
(8,8,1,'Example Structure Entry, Level 1','example-structure-entry-level-1','example-structure/example-structure-entry-level-1',NULL,1,'2024-06-14 02:25:52','2024-06-14 02:26:04','00b5933c-ed69-431e-8b4a-84cd04c9c20a'),
(9,9,1,'Example Structure Entry, Level 1','example-structure-entry-level-1','example-structure/example-structure-entry-level-1',NULL,1,'2024-06-14 02:26:05','2024-06-14 02:26:05','4742286a-9a53-43ae-b41a-a7f8064d4467'),
(10,10,1,'Example Structure Entry, Level 2','example-structure-entry-level-2','example-structure/example-structure-entry-level-2',NULL,1,'2024-06-14 02:26:12','2024-06-14 02:26:23','b0c7e126-a8e7-4730-996b-c081b3f0aded'),
(11,11,1,'Example Structure Entry, Level 2','example-structure-entry-level-2','example-structure/example-structure-entry-level-2',NULL,1,'2024-06-14 02:26:23','2024-06-14 02:26:23','3c576e2c-b357-49cb-8861-47947881b87c'),
(12,12,1,'Example Channel Entry','example-post','example-channel/example-post',NULL,1,'2024-06-14 02:42:40','2024-06-14 02:42:40','fde8db05-54eb-4c66-b13a-f16e5d541255'),
(13,13,1,'Example Channel Entry','example-channel-entry','example-channel/example-channel-entry',NULL,1,'2024-06-14 02:42:54','2024-06-14 02:42:54','92cbbccd-3020-47a9-9087-4d9033e389db'),
(14,14,1,'new entry','new-entry','example-channel/new-entry',NULL,1,'2024-06-14 11:33:27','2024-06-14 11:33:31','248810b2-c301-4f9b-a730-c365d7cf735b'),
(15,15,1,'new entry','new-entry','example-channel/new-entry',NULL,1,'2024-06-14 11:33:31','2024-06-14 11:33:31','d84d6a46-f063-4949-911c-1653625ae804'),
(16,16,1,'Homepage','homepage','__home__','{\"1cdb3f23-0acd-4dee-b97c-dbb150224874\": \"Field content\"}',1,'2024-06-19 00:31:47','2024-07-10 00:25:24','568f808a-b358-409d-9328-c6bb3e1ba1fc'),
(17,17,1,'Homepage','homepage','__home__',NULL,1,'2024-06-19 00:31:47','2024-06-19 00:31:47','9266306a-f367-4d76-b578-73454c1d5579'),
(18,18,1,'Example Single','example-single','example-single',NULL,1,'2024-06-19 19:14:42','2024-06-19 19:14:42','08a66718-65c5-43cd-ae93-a10e7a5435a1'),
(19,19,1,'Example Single','example-single','example-single',NULL,1,'2024-06-19 19:15:26','2024-06-19 19:15:26','b290afc4-6b03-46f9-bb4e-db796188cd3c'),
(20,20,1,NULL,NULL,NULL,'{\"aa58d277-892c-4f0f-b288-fcfdf3fa876e\": \"test\"}',1,'2024-06-29 04:14:58','2024-06-29 04:15:03','b46d9ace-941b-4450-909f-24a1f72015ac'),
(22,22,1,'Homepage','homepage','__home__','{\"1cdb3f23-0acd-4dee-b97c-dbb150224874\": \"Field content\"}',1,'2024-07-10 00:25:24','2024-07-10 00:25:24','efa56196-a415-4878-b2b2-2dc348672b8c');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES
(2,1,NULL,NULL,NULL,1,'2024-06-14 01:52:00',NULL,NULL,'2024-06-14 01:52:38','2024-06-14 01:52:46'),
(3,1,NULL,NULL,NULL,1,'2024-06-14 01:52:00',NULL,NULL,'2024-06-14 01:52:46','2024-06-14 01:52:46'),
(4,2,NULL,NULL,NULL,2,'2024-06-14 02:24:00',NULL,NULL,'2024-06-14 02:24:46','2024-06-14 02:24:46'),
(5,2,NULL,NULL,NULL,2,'2024-06-14 02:24:00',NULL,NULL,'2024-06-14 02:24:46','2024-06-14 02:24:46'),
(6,1,NULL,NULL,NULL,1,'2024-06-14 01:52:00',NULL,NULL,'2024-06-14 02:25:42','2024-06-14 02:25:42'),
(7,1,NULL,NULL,NULL,1,'2024-06-14 02:25:47',NULL,0,'2024-06-14 02:25:47','2024-06-14 02:25:47'),
(8,3,NULL,NULL,NULL,3,'2024-06-14 02:26:00',NULL,NULL,'2024-06-14 02:25:52','2024-06-14 02:26:05'),
(9,3,NULL,NULL,NULL,3,'2024-06-14 02:26:00',NULL,NULL,'2024-06-14 02:26:05','2024-06-14 02:26:05'),
(10,3,NULL,NULL,NULL,3,'2024-06-14 02:26:00',NULL,NULL,'2024-06-14 02:26:12','2024-06-14 02:26:12'),
(11,3,NULL,NULL,NULL,3,'2024-06-14 02:26:00',NULL,NULL,'2024-06-14 02:26:23','2024-06-14 02:26:23'),
(12,1,NULL,NULL,NULL,1,'2024-06-14 01:52:00',NULL,NULL,'2024-06-14 02:42:40','2024-06-14 02:42:40'),
(13,1,NULL,NULL,NULL,1,'2024-06-14 01:52:00',NULL,NULL,'2024-06-14 02:42:54','2024-06-14 02:42:54'),
(14,1,NULL,NULL,NULL,1,'2024-06-14 11:33:00',NULL,0,'2024-06-14 11:33:27','2024-06-14 11:33:31'),
(15,1,NULL,NULL,NULL,1,'2024-06-14 11:33:00',NULL,NULL,'2024-06-14 11:33:31','2024-06-14 11:33:31'),
(16,5,NULL,NULL,NULL,4,'2024-06-19 00:31:00',NULL,NULL,'2024-06-19 00:31:47','2024-06-19 00:31:47'),
(17,5,NULL,NULL,NULL,4,'2024-06-19 00:31:00',NULL,NULL,'2024-06-19 00:31:47','2024-06-19 00:31:47'),
(18,2,NULL,NULL,NULL,2,'2024-06-14 02:24:00',NULL,NULL,'2024-06-19 19:14:42','2024-06-19 19:14:42'),
(19,2,NULL,NULL,NULL,2,'2024-06-14 02:24:00',NULL,NULL,'2024-06-19 19:15:26','2024-06-19 19:15:26'),
(22,5,NULL,NULL,NULL,4,'2024-06-19 00:31:00',NULL,NULL,'2024-07-10 00:25:24','2024-07-10 00:25:24');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES
(2,1,1),
(3,1,1),
(6,1,1),
(7,1,1),
(8,1,1),
(9,1,1),
(10,1,1),
(11,1,1),
(12,1,1),
(13,1,1),
(14,1,1),
(15,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES
(1,1,'Example Channel Entry Type','exampleChannelEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-13 23:38:58','2024-06-14 02:23:55',NULL,'95ef0b64-7fa5-4a78-96c8-54053c025f38'),
(2,2,'Example Single Entry Type','exampleSingleEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-14 02:24:43','2024-06-14 02:24:43',NULL,'e028dd6d-44ee-41f5-b575-4921ba562311'),
(3,3,'Example Structure Entry Type','exampleStructureEntryType','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-14 02:25:16','2024-06-14 02:25:16',NULL,'fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f'),
(4,4,'Homepage','homepage','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-06-19 00:31:40','2024-06-19 00:31:40',NULL,'721b2b6e-f75a-4e5b-9b43-0de469c9dbb4');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"6e00185e-96a3-40d7-b92d-d06871aa709c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"5f72b360-b910-4b9f-91ba-41dfaa2fcc6e\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-13 23:38:58','2024-06-13 23:38:58',NULL,'19ffc8b9-bed0-4915-8302-4daf927de65b'),
(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"09bea70c-0a4c-4de6-a816-955967737fb0\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"6f91d278-2c6f-4a03-9665-ba57e9afad90\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-14 02:24:43','2024-06-14 02:24:43',NULL,'f4d041e1-3b65-4df6-9cf8-1d935a7e778a'),
(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"e61acb8a-41ef-405c-abd1-61d4f74c4a54\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"11263d96-3f07-4eb3-8d6a-742709a84a47\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-14 02:25:16','2024-06-14 02:25:16',NULL,'0072b5a5-fa19-442b-a142-b708534fc1e3'),
(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2b4376eb-29f2-4c76-ae26-74aa30213bf4\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"1211497e-ee4f-482a-bab6-02ccb36fe0d6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"1cdb3f23-0acd-4dee-b97c-dbb150224874\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7a918867-2d16-4cc7-9e43-a3f629ef32d6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-19 00:31:40','2024-07-10 00:25:07',NULL,'fba726e9-ea21-4da8-b7ef-57dcd88e4b33'),
(5,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"9a799b05-5144-4854-9c77-8f6aa4547744\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"aa58d277-892c-4f0f-b288-fcfdf3fa876e\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9e349eb4-3b2c-4db5-97b2-833c50df3605\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-29 04:14:58','2024-06-29 04:14:58','2024-07-03 01:58:09','bee2ef83-9e75-4269-a176-75b61ed78a0d');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES
(2,'Example Field','exampleField','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-07-10 00:24:27','2024-07-10 00:24:27','7a918867-2d16-4cc7-9e43-a3f629ef32d6');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `globalsets` VALUES
(20,'Example Global Set','exampleGlobalSet',5,1,'2024-06-29 04:14:58','2024-06-29 04:14:58','842cf81b-481b-403d-bd40-88c87adb099b');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES
(1,'Public Schema','[\"sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78:read\", \"sections.f527f66e-862e-4c16-8439-cdb3e1f894c3:read\", \"sections.87840c86-d676-4511-96cf-bc39bd159b64:read\", \"sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32:read\", \"sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117:read\"]',1,'2024-06-13 23:28:57','2024-07-03 01:58:09','83a107ea-357d-4836-b525-14319446f05c');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqltokens` VALUES
(1,'Public Token','__PUBLIC__',1,NULL,'2024-07-10 01:10:21',NULL,'2024-06-13 23:34:27','2024-07-10 01:10:21','5a0e85f1-f122-41ef-8584-93f31ee16b68');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES
(1,'5.2.3','5.0.0.21',0,'javibqlcagan','3@msmfqdmoyz','2024-06-13 21:42:33','2024-07-10 00:25:07','245750f0-a544-43e8-81ef-67e6d847ec2d');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','91031ca0-6ae2-4f9d-bf76-7a1a1e42c1ac'),
(2,'craft','m221101_115859_create_entries_authors_table','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','6eccb159-d772-4c7a-a3e6-aaac6ff22a9f'),
(3,'craft','m221107_112121_add_max_authors_to_sections','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','0826693f-0806-4495-bf5b-5415f9885c4e'),
(4,'craft','m221205_082005_translatable_asset_alt_text','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','552f3380-7796-486f-bc14-d60c2042fa25'),
(5,'craft','m230314_110309_add_authenticator_table','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','93e268aa-c0e5-4152-bb29-14299ee21dcd'),
(6,'craft','m230314_111234_add_webauthn_table','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','9ca00953-3fa9-4a96-a4b8-6732bfec032f'),
(7,'craft','m230503_120303_add_recoverycodes_table','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','6481d205-edaa-4c77-bc5e-ca346459383b'),
(8,'craft','m230511_000000_field_layout_configs','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','ec5a6252-0bfa-4c64-872a-0213f6d6b82b'),
(9,'craft','m230511_215903_content_refactor','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','c3d92c5e-26e8-4cdf-ad93-d011f452f7dd'),
(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','05bf383a-e1bc-462d-b2a5-29f3ccb1cfc3'),
(11,'craft','m230524_000001_entry_type_icons','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','3ec3a31a-1cb9-4d2b-a66d-2130b7812e90'),
(12,'craft','m230524_000002_entry_type_colors','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','d2e9ed16-6223-42cc-9ff7-283372b8018e'),
(13,'craft','m230524_220029_global_entry_types','2024-06-13 21:42:33','2024-06-13 21:42:33','2024-06-13 21:42:33','76231245-7f1c-4fc1-a4ec-98bfd9384baf'),
(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','4e061d49-94f3-414b-9dc9-45db39e4d44c'),
(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','03d0d5aa-7dcc-4ad0-9d22-da3e4078d739'),
(16,'craft','m230616_173810_kill_field_groups','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','01a1b333-9677-4e4b-9c29-efd665761c62'),
(17,'craft','m230616_183820_remove_field_name_limit','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','49a1d613-b931-47c0-af87-4398cfaac759'),
(18,'craft','m230617_070415_entrify_matrix_blocks','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','ad5f2064-d6b2-43fb-a1de-431095364482'),
(19,'craft','m230710_162700_element_activity','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','53ede852-a8a2-4246-884e-fe51314090e5'),
(20,'craft','m230820_162023_fix_cache_id_type','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','1726b92b-4a29-450a-815e-0afa188345cd'),
(21,'craft','m230826_094050_fix_session_id_type','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','4730357c-ee03-42ad-bf37-db34d9154e14'),
(22,'craft','m230904_190356_address_fields','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','b3d4eb85-33b1-476c-bdb2-7ab89cd9c28e'),
(23,'craft','m230928_144045_add_subpath_to_volumes','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','b7ec92ea-ac46-4d25-ba45-1f05792d67ad'),
(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','7dca849a-a9ea-4a5f-bc31-d9062db533de'),
(25,'craft','m231213_030600_element_bulk_ops','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','29421c16-aec7-4ee7-b499-7877f972acd9'),
(26,'craft','m240129_150719_sites_language_amend_length','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','5b7c98ad-bfa3-41a9-9a78-e9433eee3859'),
(27,'craft','m240206_035135_convert_json_columns','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','774c184d-9010-479b-bd11-8fe47c00cb42'),
(28,'craft','m240207_182452_address_line_3','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','92427adb-ffd6-44f7-bc48-dc32f3d527a4'),
(29,'craft','m240302_212719_solo_preview_targets','2024-06-13 21:42:34','2024-06-13 21:42:34','2024-06-13 21:42:34','50bf93a6-4b1e-4631-b9a0-6494c1ca3928'),
(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-06-21 02:51:40','2024-06-21 02:51:40','2024-06-21 02:51:40','0d3ee234-c0e5-4913-b69a-3b8b98f0cde8');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES
('dateModified','1720571107'),
('email.fromEmail','\"olets@olets.dev\"'),
('email.fromName','\"astro-craftcms\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.color','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elementCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocomplete','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.autocorrect','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.class','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.disabled','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.elementCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.id','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.includeInCards','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.inputType','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.instructions','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.label','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.max','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.min','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.name','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.orientation','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.placeholder','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.readonly','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.requirable','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.size','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.step','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.tip','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.title','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.uid','\"1211497e-ee4f-482a-bab6-02ccb36fe0d6\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.userCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.warning','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.0.width','100'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.elementCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.fieldUid','\"7a918867-2d16-4cc7-9e43-a3f629ef32d6\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.handle','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.includeInCards','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.instructions','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.label','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.required','false'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.tip','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.uid','\"1cdb3f23-0acd-4dee-b97c-dbb150224874\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.userCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.warning','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.elements.1.width','100'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.name','\"Content\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.uid','\"2b4376eb-29f2-4c76-ae26-74aa30213bf4\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.fieldLayouts.fba726e9-ea21-4da8-b7ef-57dcd88e4b33.tabs.0.userCondition','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.handle','\"homepage\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.hasTitleField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.icon','\"\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.name','\"Homepage\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.showSlugField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.showStatusField','true'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.slugTranslationKeyFormat','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.slugTranslationMethod','\"site\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleFormat','\"\"'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleTranslationKeyFormat','null'),
('entryTypes.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4.titleTranslationMethod','\"site\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.color','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elementCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocomplete','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.autocorrect','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.class','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.disabled','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.elementCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.id','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.includeInCards','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.inputType','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.instructions','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.label','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.max','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.min','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.name','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.orientation','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.placeholder','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.readonly','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.requirable','false'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.size','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.step','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.tip','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.title','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.uid','\"5f72b360-b910-4b9f-91ba-41dfaa2fcc6e\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.userCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.warning','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.elements.0.width','100'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.name','\"Content\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.uid','\"6e00185e-96a3-40d7-b92d-d06871aa709c\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.fieldLayouts.19ffc8b9-bed0-4915-8302-4daf927de65b.tabs.0.userCondition','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.handle','\"exampleChannelEntryType\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.hasTitleField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.icon','\"\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.name','\"Example Channel Entry Type\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.showSlugField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.showStatusField','true'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.slugTranslationKeyFormat','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.slugTranslationMethod','\"site\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleFormat','\"\"'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleTranslationKeyFormat','null'),
('entryTypes.95ef0b64-7fa5-4a78-96c8-54053c025f38.titleTranslationMethod','\"site\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.color','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elementCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocomplete','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.autocorrect','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.class','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.disabled','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.elementCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.id','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.includeInCards','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.inputType','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.instructions','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.label','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.max','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.min','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.name','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.orientation','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.placeholder','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.readonly','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.requirable','false'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.size','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.step','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.tip','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.title','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.uid','\"6f91d278-2c6f-4a03-9665-ba57e9afad90\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.userCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.warning','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.elements.0.width','100'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.name','\"Content\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.uid','\"09bea70c-0a4c-4de6-a816-955967737fb0\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.fieldLayouts.f4d041e1-3b65-4df6-9cf8-1d935a7e778a.tabs.0.userCondition','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.handle','\"exampleSingleEntryType\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.hasTitleField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.icon','\"\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.name','\"Example Single Entry Type\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.showSlugField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.showStatusField','true'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.slugTranslationKeyFormat','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.slugTranslationMethod','\"site\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleFormat','\"\"'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleTranslationKeyFormat','null'),
('entryTypes.e028dd6d-44ee-41f5-b575-4921ba562311.titleTranslationMethod','\"site\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.color','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elementCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocomplete','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.autocorrect','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.class','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.disabled','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.elementCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.id','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.includeInCards','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.inputType','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.instructions','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.label','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.max','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.min','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.name','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.orientation','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.placeholder','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.readonly','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.requirable','false'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.size','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.step','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.tip','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.title','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.uid','\"11263d96-3f07-4eb3-8d6a-742709a84a47\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.userCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.warning','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.elements.0.width','100'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.name','\"Content\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.uid','\"e61acb8a-41ef-405c-abd1-61d4f74c4a54\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.fieldLayouts.0072b5a5-fa19-442b-a142-b708534fc1e3.tabs.0.userCondition','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.handle','\"exampleStructureEntryType\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.hasTitleField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.icon','\"\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.name','\"Example Structure Entry Type\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.showSlugField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.showStatusField','true'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.slugTranslationKeyFormat','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.slugTranslationMethod','\"site\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleFormat','\"\"'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleTranslationKeyFormat','null'),
('entryTypes.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f.titleTranslationMethod','\"site\"'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.columnSuffix','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.handle','\"exampleField\"'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.instructions','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.name','\"Example Field\"'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.searchable','false'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.byteLimit','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.charLimit','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.code','false'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.initialRows','4'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.multiline','false'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.placeholder','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.settings.uiMode','\"normal\"'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.translationKeyFormat','null'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.translationMethod','\"none\"'),
('fields.7a918867-2d16-4cc7-9e43-a3f629ef32d6.type','\"craft\\\\fields\\\\PlainText\"'),
('graphql.publicToken.enabled','true'),
('graphql.publicToken.expiryDate','null'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.isPublic','true'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.name','\"Public Schema\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.0','\"sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.1','\"sections.f527f66e-862e-4c16-8439-cdb3e1f894c3:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.2','\"sections.87840c86-d676-4511-96cf-bc39bd159b64:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.3','\"sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32:read\"'),
('graphql.schemas.83a107ea-357d-4836-b525-14319446f05c.scope.4','\"sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117:read\"'),
('meta.__names__.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78','\"ssg-astro-craftcms\"'),
('meta.__names__.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32','\"Example Channel\"'),
('meta.__names__.721b2b6e-f75a-4e5b-9b43-0de469c9dbb4','\"Homepage\"'),
('meta.__names__.7a918867-2d16-4cc7-9e43-a3f629ef32d6','\"Example Field\"'),
('meta.__names__.83a107ea-357d-4836-b525-14319446f05c','\"Public Schema\"'),
('meta.__names__.863cff4f-f659-488d-9614-5d2b915a50ee','\"astro-craftcms\"'),
('meta.__names__.87840c86-d676-4511-96cf-bc39bd159b64','\"Homepage\"'),
('meta.__names__.95ef0b64-7fa5-4a78-96c8-54053c025f38','\"Example Channel Entry Type\"'),
('meta.__names__.b34ffb6b-3496-4a01-a7b4-92e89cc74117','\"Example Structure\"'),
('meta.__names__.e028dd6d-44ee-41f5-b575-4921ba562311','\"Example Single Entry Type\"'),
('meta.__names__.f527f66e-862e-4c16-8439-cdb3e1f894c3','\"Example Single\"'),
('meta.__names__.fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f','\"Example Structure Entry Type\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.defaultPlacement','\"end\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.enableVersioning','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.entryTypes.0','\"95ef0b64-7fa5-4a78-96c8-54053c025f38\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.handle','\"exampleChannel\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.maxAuthors','1'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.name','\"Example Channel\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.propagationMethod','\"all\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-channel/{slug}\"'),
('sections.31cbaa90-6504-4e89-87f0-d8c2ed3f5f32.type','\"channel\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.defaultPlacement','\"end\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.enableVersioning','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.entryTypes.0','\"721b2b6e-f75a-4e5b-9b43-0de469c9dbb4\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.handle','\"homepage\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.maxAuthors','1'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.name','\"Homepage\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.propagationMethod','\"all\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"__home__\"'),
('sections.87840c86-d676-4511-96cf-bc39bd159b64.type','\"single\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.defaultPlacement','\"end\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.enableVersioning','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.entryTypes.0','\"fb3e2e8c-14ef-4f19-90b3-64d37d6ea29f\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.handle','\"exampleStructure\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.maxAuthors','1'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.name','\"Example Structure\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.propagationMethod','\"all\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-structure/{slug}\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.structure.maxLevels','null'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.structure.uid','\"c72b261c-2184-4610-b38e-84dc3cdfce9d\"'),
('sections.b34ffb6b-3496-4a01-a7b4-92e89cc74117.type','\"structure\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.defaultPlacement','\"end\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.enableVersioning','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.entryTypes.0','\"e028dd6d-44ee-41f5-b575-4921ba562311\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.handle','\"exampleSingle\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.maxAuthors','1'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.name','\"Example Single\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.propagationMethod','\"all\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabledByDefault','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.template','null'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.siteSettings.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.uriFormat','\"example-single\"'),
('sections.f527f66e-862e-4c16-8439-cdb3e1f894c3.type','\"single\"'),
('siteGroups.863cff4f-f659-488d-9614-5d2b915a50ee.name','\"astro-craftcms\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.enabled','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.handle','\"default\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.hasUrls','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.language','\"en-US\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.name','\"ssg-astro-craftcms\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.primary','true'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.siteGroup','\"863cff4f-f659-488d-9614-5d2b915a50ee\"'),
('sites.0bda1c6b-607d-4b82-8274-4bdc4f5a2a78.sortOrder','1'),
('system.edition','\"solo\"'),
('system.live','true'),
('system.name','\"astro-craftcms\"'),
('system.schemaVersion','\"5.0.0.21\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.require2fa','false'),
('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES
(1,2,1,1,''),
(2,4,1,1,NULL),
(3,2,1,2,''),
(4,8,1,1,''),
(5,10,1,1,''),
(6,2,1,3,''),
(7,2,1,4,''),
(8,14,1,1,''),
(9,16,1,1,NULL),
(10,4,1,2,NULL),
(11,4,1,3,NULL),
(12,16,1,2,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES
(1,'email',0,1,' changeme example com '),
(1,'firstname',0,1,''),
(1,'fullname',0,1,''),
(1,'lastname',0,1,''),
(1,'slug',0,1,''),
(1,'username',0,1,' admin '),
(2,'slug',0,1,' example channel entry '),
(2,'title',0,1,' example channel entry '),
(4,'slug',0,1,' example single '),
(4,'title',0,1,' example single '),
(7,'slug',0,1,' temp enucutvdvlhyxqvxzvkhifdoxmtbvlnwkaxm '),
(7,'title',0,1,''),
(8,'slug',0,1,' example structure entry level 1 '),
(8,'title',0,1,' example structure entry level 1 '),
(10,'slug',0,1,' example structure entry level 2 '),
(10,'title',0,1,' example structure entry level 2 '),
(14,'slug',0,1,' new entry '),
(14,'title',0,1,' new entry '),
(16,'slug',0,1,' homepage '),
(16,'title',0,1,' homepage '),
(20,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES
(1,NULL,'Example Channel','exampleChannel','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-13 23:40:16','2024-06-14 02:33:20',NULL,'31cbaa90-6504-4e89-87f0-d8c2ed3f5f32'),
(2,NULL,'Example Single','exampleSingle','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-14 02:24:46','2024-06-19 19:15:26',NULL,'f527f66e-862e-4c16-8439-cdb3e1f894c3'),
(3,1,'Example Structure','exampleStructure','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-14 02:25:22','2024-06-14 02:25:27',NULL,'b34ffb6b-3496-4a01-a7b4-92e89cc74117'),
(4,NULL,'no uri','noUri','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-15 20:32:54','2024-06-15 20:32:54','2024-06-15 22:00:18','b76894ee-09a1-4b67-997e-fa121feeed7f'),
(5,NULL,'Homepage','homepage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-19 00:31:47','2024-06-19 00:31:47',NULL,'87840c86-d676-4511-96cf-bc39bd159b64');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES
(1,1,1),
(2,2,1),
(3,3,1),
(4,1,1),
(5,4,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'example-channel/{slug}',NULL,1,'2024-06-13 23:40:16','2024-06-14 02:33:20','08ef6503-688a-49cb-b930-8b4787b5a597'),
(2,2,1,1,'example-single',NULL,1,'2024-06-14 02:24:46','2024-06-19 19:15:26','c1947f0c-28b4-4641-b843-bdf1d5308dd9'),
(3,3,1,1,'example-structure/{slug}',NULL,1,'2024-06-14 02:25:22','2024-06-14 02:25:22','070d1e62-be48-4fdd-8c92-578c227b055a'),
(4,4,1,0,NULL,NULL,1,'2024-06-15 20:32:54','2024-06-15 20:32:54','76800c65-edd1-402e-9569-3f754eb41b6c'),
(5,5,1,1,'__home__',NULL,1,'2024-06-19 00:31:47','2024-06-19 00:31:47','741a698b-7003-4717-b2d2-255c75f6c4c9');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES
(1,'astro-craftcms','2024-06-13 21:42:33','2024-06-13 21:42:33',NULL,'863cff4f-f659-488d-9614-5d2b915a50ee');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES
(1,1,1,'1','ssg-astro-craftcms','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-06-13 21:42:33','2024-06-21 07:18:45',NULL,'0bda1c6b-607d-4b82-8274-4bdc4f5a2a78');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES
(1,1,NULL,1,1,6,0,'2024-06-14 02:25:52','2024-06-14 02:26:22','d1629e0c-b211-4086-9dde-a30ae0fa9936'),
(2,1,8,1,2,5,1,'2024-06-14 02:25:52','2024-06-14 02:26:22','ceee9362-8edb-4b48-ae94-bf619b3593dc'),
(3,1,10,1,3,4,2,'2024-06-14 02:26:12','2024-06-14 02:26:22','255869d8-efa0-41c9-942c-faccdbd67811');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES
(1,NULL,'2024-06-14 02:25:27','2024-06-14 02:25:27',NULL,'c72b261c-2184-4610-b38e-84dc3cdfce9d');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES
(1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'changeme@example.com','$2y$13$UAO8CwONAr93s.HjLScFjuTfGPX7L.KmrMAc3RhDsQH3GTP1AM2yK','2024-07-10 00:10:31',NULL,NULL,NULL,NULL,NULL,1,'$2y$13$k45ulYeWWkR1V.SzwYbFt.OR.J6G2EVSu229YeN76yQpff/1hw682','2024-06-14 22:02:57',NULL,0,'2024-06-14 01:23:10','2024-06-13 21:42:33','2024-07-10 00:10:31');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES
(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-06-13 23:21:15','2024-06-13 23:21:15','85a3f1e4-5f8d-48eb-8360-e3e78da2c53b'),
(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-06-13 23:21:15','2024-06-13 23:21:15','e8ad7cd2-3e0d-4a1e-8253-d1283bd19d01'),
(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-06-13 23:21:15','2024-06-13 23:21:15','f2b3b9a6-81a9-434f-aca0-ee4f8373de62'),
(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-06-13 23:21:15','2024-06-13 23:21:15','c6ee6c9c-0f48-43a8-974c-ef8ecaf2d145');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10  1:11:37
